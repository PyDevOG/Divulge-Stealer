﻿namespace Divulge.builder.Components.Forms
{
    partial class AssemblyEditorForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(AssemblyEditorForm));
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties57 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties58 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties59 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties60 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties61 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties62 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties63 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties64 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties65 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties66 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties67 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties68 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties69 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties70 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties71 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties72 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties73 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties74 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties75 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties76 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges5 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges6 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties77 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties78 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties79 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties80 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties81 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties82 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties83 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties84 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.bunifuElipse1 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panel1 = new System.Windows.Forms.Panel();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuColorTransition1 = new Bunifu.UI.WinForms.BunifuColorTransition(this.components);
            this.bunifuShadowPanel1 = new Bunifu.UI.WinForms.BunifuShadowPanel();
            this.bunifuLabel9 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtInternalName = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuLabel10 = new Bunifu.UI.WinForms.BunifuLabel();
            this.bunifuLabel4 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtOriginalFilename = new Bunifu.UI.WinForms.BunifuTextBox();
            this.txtLegalCopyright = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuLabel5 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtProductName = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuLabel3 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtFileDescription = new Bunifu.UI.WinForms.BunifuTextBox();
            this.btnCancel = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.bunifuLabel6 = new Bunifu.UI.WinForms.BunifuLabel();
            this.btnOk = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.txtLegalTrademarks = new Bunifu.UI.WinForms.BunifuTextBox();
            this.bunifuLabel2 = new Bunifu.UI.WinForms.BunifuLabel();
            this.txtCompanyName = new Bunifu.UI.WinForms.BunifuTextBox();
            this.panel1.SuspendLayout();
            this.bunifuShadowPanel1.SuspendLayout();
            this.SuspendLayout();
            // 
            // bunifuElipse1
            // 
            this.bunifuElipse1.ElipseRadius = 5;
            this.bunifuElipse1.TargetControl = this;
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.panel1.Controls.Add(this.bunifuLabel1);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Location = new System.Drawing.Point(2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.panel1.Size = new System.Drawing.Size(482, 34);
            this.panel1.TabIndex = 0;
            this.panel1.Paint += new System.Windows.Forms.PaintEventHandler(this.panel1_Paint);
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Drag_On_Mousedown);
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AllowParentOverrides = false;
            this.bunifuLabel1.AutoEllipsis = true;
            this.bunifuLabel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold);
            this.bunifuLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel1.Location = new System.Drawing.Point(206, 7);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(82, 21);
            this.bunifuLabel1.TabIndex = 13;
            this.bunifuLabel1.Text = "Assembly";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuColorTransition1
            // 
            this.bunifuColorTransition1.AutoTransition = false;
            this.bunifuColorTransition1.ColorArray = new System.Drawing.Color[] {
        System.Drawing.Color.Purple,
        System.Drawing.Color.Indigo,
        System.Drawing.Color.Aqua,
        System.Drawing.Color.Lime,
        System.Drawing.Color.Yellow,
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0))))),
        System.Drawing.Color.Red};
            this.bunifuColorTransition1.EndColor = System.Drawing.Color.White;
            this.bunifuColorTransition1.Interval = 1;
            this.bunifuColorTransition1.ProgessValue = 0;
            this.bunifuColorTransition1.StartColor = System.Drawing.Color.White;
            this.bunifuColorTransition1.TransitionControl = this;
            // 
            // bunifuShadowPanel1
            // 
            this.bunifuShadowPanel1.BackColor = System.Drawing.Color.Transparent;
            this.bunifuShadowPanel1.BorderColor = System.Drawing.Color.Transparent;
            this.bunifuShadowPanel1.BorderRadius = 1;
            this.bunifuShadowPanel1.BorderThickness = 1;
            this.bunifuShadowPanel1.Controls.Add(this.bunifuLabel9);
            this.bunifuShadowPanel1.Controls.Add(this.txtInternalName);
            this.bunifuShadowPanel1.Controls.Add(this.bunifuLabel10);
            this.bunifuShadowPanel1.Controls.Add(this.bunifuLabel4);
            this.bunifuShadowPanel1.Controls.Add(this.txtOriginalFilename);
            this.bunifuShadowPanel1.Controls.Add(this.txtLegalCopyright);
            this.bunifuShadowPanel1.Controls.Add(this.bunifuLabel5);
            this.bunifuShadowPanel1.Controls.Add(this.txtProductName);
            this.bunifuShadowPanel1.Controls.Add(this.bunifuLabel3);
            this.bunifuShadowPanel1.Controls.Add(this.txtFileDescription);
            this.bunifuShadowPanel1.Controls.Add(this.btnCancel);
            this.bunifuShadowPanel1.Controls.Add(this.bunifuLabel6);
            this.bunifuShadowPanel1.Controls.Add(this.btnOk);
            this.bunifuShadowPanel1.Controls.Add(this.txtLegalTrademarks);
            this.bunifuShadowPanel1.Controls.Add(this.bunifuLabel2);
            this.bunifuShadowPanel1.Controls.Add(this.txtCompanyName);
            this.bunifuShadowPanel1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuShadowPanel1.FillStyle = Bunifu.UI.WinForms.BunifuShadowPanel.FillStyles.Solid;
            this.bunifuShadowPanel1.GradientMode = Bunifu.UI.WinForms.BunifuShadowPanel.GradientModes.Vertical;
            this.bunifuShadowPanel1.Location = new System.Drawing.Point(2, 36);
            this.bunifuShadowPanel1.Name = "bunifuShadowPanel1";
            this.bunifuShadowPanel1.Padding = new System.Windows.Forms.Padding(2);
            this.bunifuShadowPanel1.PanelColor = System.Drawing.Color.Black;
            this.bunifuShadowPanel1.PanelColor2 = System.Drawing.Color.Black;
            this.bunifuShadowPanel1.ShadowColor = System.Drawing.Color.DarkGray;
            this.bunifuShadowPanel1.ShadowDept = 2;
            this.bunifuShadowPanel1.ShadowDepth = 0;
            this.bunifuShadowPanel1.ShadowStyle = Bunifu.UI.WinForms.BunifuShadowPanel.ShadowStyles.Surrounded;
            this.bunifuShadowPanel1.ShadowTopLeftVisible = false;
            this.bunifuShadowPanel1.Size = new System.Drawing.Size(482, 327);
            this.bunifuShadowPanel1.Style = Bunifu.UI.WinForms.BunifuShadowPanel.BevelStyles.Flat;
            this.bunifuShadowPanel1.TabIndex = 1;
            // 
            // bunifuLabel9
            // 
            this.bunifuLabel9.AllowParentOverrides = false;
            this.bunifuLabel9.AutoEllipsis = false;
            this.bunifuLabel9.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel9.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel9.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel9.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel9.Location = new System.Drawing.Point(9, 192);
            this.bunifuLabel9.Name = "bunifuLabel9";
            this.bunifuLabel9.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel9.Size = new System.Drawing.Size(85, 17);
            this.bunifuLabel9.TabIndex = 20;
            this.bunifuLabel9.Text = "Internal Name:";
            this.bunifuLabel9.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel9.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtInternalName
            // 
            this.txtInternalName.AcceptsReturn = false;
            this.txtInternalName.AcceptsTab = false;
            this.txtInternalName.AnimationSpeed = 200;
            this.txtInternalName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtInternalName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtInternalName.BackColor = System.Drawing.Color.White;
            this.txtInternalName.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtInternalName.BackgroundImage")));
            this.txtInternalName.BorderColorActive = System.Drawing.Color.Transparent;
            this.txtInternalName.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtInternalName.BorderColorHover = System.Drawing.Color.Transparent;
            this.txtInternalName.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtInternalName.BorderRadius = 1;
            this.txtInternalName.BorderThickness = 1;
            this.txtInternalName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtInternalName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtInternalName.DefaultFont = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtInternalName.DefaultText = "";
            this.txtInternalName.FillColor = System.Drawing.Color.Black;
            this.txtInternalName.ForeColor = System.Drawing.Color.White;
            this.txtInternalName.HideSelection = true;
            this.txtInternalName.IconLeft = null;
            this.txtInternalName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtInternalName.IconPadding = 10;
            this.txtInternalName.IconRight = null;
            this.txtInternalName.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtInternalName.Lines = new string[0];
            this.txtInternalName.Location = new System.Drawing.Point(124, 189);
            this.txtInternalName.MaxLength = 32767;
            this.txtInternalName.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtInternalName.Modified = false;
            this.txtInternalName.Multiline = false;
            this.txtInternalName.Name = "txtInternalName";
            stateProperties57.BorderColor = System.Drawing.Color.Transparent;
            stateProperties57.FillColor = System.Drawing.Color.Empty;
            stateProperties57.ForeColor = System.Drawing.Color.Empty;
            stateProperties57.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtInternalName.OnActiveState = stateProperties57;
            stateProperties58.BorderColor = System.Drawing.Color.Silver;
            stateProperties58.FillColor = System.Drawing.Color.Black;
            stateProperties58.ForeColor = System.Drawing.Color.Transparent;
            stateProperties58.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.txtInternalName.OnDisabledState = stateProperties58;
            stateProperties59.BorderColor = System.Drawing.Color.Transparent;
            stateProperties59.FillColor = System.Drawing.Color.Empty;
            stateProperties59.ForeColor = System.Drawing.Color.Empty;
            stateProperties59.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtInternalName.OnHoverState = stateProperties59;
            stateProperties60.BorderColor = System.Drawing.Color.Silver;
            stateProperties60.FillColor = System.Drawing.Color.Black;
            stateProperties60.ForeColor = System.Drawing.Color.White;
            stateProperties60.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtInternalName.OnIdleState = stateProperties60;
            this.txtInternalName.Padding = new System.Windows.Forms.Padding(3);
            this.txtInternalName.PasswordChar = '\0';
            this.txtInternalName.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.txtInternalName.PlaceholderText = "Google Services";
            this.txtInternalName.ReadOnly = false;
            this.txtInternalName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtInternalName.SelectedText = "";
            this.txtInternalName.SelectionLength = 0;
            this.txtInternalName.SelectionStart = 0;
            this.txtInternalName.ShortcutsEnabled = true;
            this.txtInternalName.Size = new System.Drawing.Size(297, 24);
            this.txtInternalName.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtInternalName.TabIndex = 21;
            this.txtInternalName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtInternalName.TextMarginBottom = 0;
            this.txtInternalName.TextMarginLeft = 3;
            this.txtInternalName.TextMarginTop = 0;
            this.txtInternalName.TextPlaceholder = "Google Services";
            this.txtInternalName.UseSystemPasswordChar = false;
            this.txtInternalName.WordWrap = true;
            // 
            // bunifuLabel10
            // 
            this.bunifuLabel10.AllowParentOverrides = false;
            this.bunifuLabel10.AutoEllipsis = false;
            this.bunifuLabel10.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel10.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel10.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel10.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel10.Location = new System.Drawing.Point(9, 228);
            this.bunifuLabel10.Name = "bunifuLabel10";
            this.bunifuLabel10.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel10.Size = new System.Drawing.Size(104, 17);
            this.bunifuLabel10.TabIndex = 18;
            this.bunifuLabel10.Text = "Original Filename:";
            this.bunifuLabel10.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel10.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // bunifuLabel4
            // 
            this.bunifuLabel4.AllowParentOverrides = false;
            this.bunifuLabel4.AutoEllipsis = false;
            this.bunifuLabel4.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel4.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel4.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel4.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel4.Location = new System.Drawing.Point(9, 121);
            this.bunifuLabel4.Name = "bunifuLabel4";
            this.bunifuLabel4.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel4.Size = new System.Drawing.Size(95, 17);
            this.bunifuLabel4.TabIndex = 20;
            this.bunifuLabel4.Text = "Legal Copyright:";
            this.bunifuLabel4.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel4.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtOriginalFilename
            // 
            this.txtOriginalFilename.AcceptsReturn = false;
            this.txtOriginalFilename.AcceptsTab = false;
            this.txtOriginalFilename.AnimationSpeed = 200;
            this.txtOriginalFilename.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtOriginalFilename.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtOriginalFilename.BackColor = System.Drawing.Color.White;
            this.txtOriginalFilename.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtOriginalFilename.BackgroundImage")));
            this.txtOriginalFilename.BorderColorActive = System.Drawing.Color.Transparent;
            this.txtOriginalFilename.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtOriginalFilename.BorderColorHover = System.Drawing.Color.Transparent;
            this.txtOriginalFilename.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtOriginalFilename.BorderRadius = 1;
            this.txtOriginalFilename.BorderThickness = 1;
            this.txtOriginalFilename.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtOriginalFilename.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtOriginalFilename.DefaultFont = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtOriginalFilename.DefaultText = "";
            this.txtOriginalFilename.FillColor = System.Drawing.Color.Black;
            this.txtOriginalFilename.ForeColor = System.Drawing.Color.White;
            this.txtOriginalFilename.HideSelection = true;
            this.txtOriginalFilename.IconLeft = null;
            this.txtOriginalFilename.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtOriginalFilename.IconPadding = 10;
            this.txtOriginalFilename.IconRight = null;
            this.txtOriginalFilename.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtOriginalFilename.Lines = new string[0];
            this.txtOriginalFilename.Location = new System.Drawing.Point(124, 225);
            this.txtOriginalFilename.MaxLength = 32767;
            this.txtOriginalFilename.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtOriginalFilename.Modified = false;
            this.txtOriginalFilename.Multiline = false;
            this.txtOriginalFilename.Name = "txtOriginalFilename";
            stateProperties61.BorderColor = System.Drawing.Color.Transparent;
            stateProperties61.FillColor = System.Drawing.Color.Empty;
            stateProperties61.ForeColor = System.Drawing.Color.Empty;
            stateProperties61.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtOriginalFilename.OnActiveState = stateProperties61;
            stateProperties62.BorderColor = System.Drawing.Color.Silver;
            stateProperties62.FillColor = System.Drawing.Color.Black;
            stateProperties62.ForeColor = System.Drawing.Color.Transparent;
            stateProperties62.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.txtOriginalFilename.OnDisabledState = stateProperties62;
            stateProperties63.BorderColor = System.Drawing.Color.Transparent;
            stateProperties63.FillColor = System.Drawing.Color.Empty;
            stateProperties63.ForeColor = System.Drawing.Color.Empty;
            stateProperties63.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtOriginalFilename.OnHoverState = stateProperties63;
            stateProperties64.BorderColor = System.Drawing.Color.Silver;
            stateProperties64.FillColor = System.Drawing.Color.Black;
            stateProperties64.ForeColor = System.Drawing.Color.White;
            stateProperties64.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtOriginalFilename.OnIdleState = stateProperties64;
            this.txtOriginalFilename.Padding = new System.Windows.Forms.Padding(3);
            this.txtOriginalFilename.PasswordChar = '\0';
            this.txtOriginalFilename.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.txtOriginalFilename.PlaceholderText = "GoogleUpdater.exe";
            this.txtOriginalFilename.ReadOnly = false;
            this.txtOriginalFilename.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtOriginalFilename.SelectedText = "";
            this.txtOriginalFilename.SelectionLength = 0;
            this.txtOriginalFilename.SelectionStart = 0;
            this.txtOriginalFilename.ShortcutsEnabled = true;
            this.txtOriginalFilename.Size = new System.Drawing.Size(297, 24);
            this.txtOriginalFilename.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtOriginalFilename.TabIndex = 19;
            this.txtOriginalFilename.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtOriginalFilename.TextMarginBottom = 0;
            this.txtOriginalFilename.TextMarginLeft = 3;
            this.txtOriginalFilename.TextMarginTop = 0;
            this.txtOriginalFilename.TextPlaceholder = "GoogleUpdater.exe";
            this.txtOriginalFilename.UseSystemPasswordChar = false;
            this.txtOriginalFilename.WordWrap = true;
            // 
            // txtLegalCopyright
            // 
            this.txtLegalCopyright.AcceptsReturn = false;
            this.txtLegalCopyright.AcceptsTab = false;
            this.txtLegalCopyright.AnimationSpeed = 200;
            this.txtLegalCopyright.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtLegalCopyright.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtLegalCopyright.BackColor = System.Drawing.Color.White;
            this.txtLegalCopyright.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtLegalCopyright.BackgroundImage")));
            this.txtLegalCopyright.BorderColorActive = System.Drawing.Color.Transparent;
            this.txtLegalCopyright.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtLegalCopyright.BorderColorHover = System.Drawing.Color.Transparent;
            this.txtLegalCopyright.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtLegalCopyright.BorderRadius = 1;
            this.txtLegalCopyright.BorderThickness = 1;
            this.txtLegalCopyright.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtLegalCopyright.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLegalCopyright.DefaultFont = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLegalCopyright.DefaultText = "";
            this.txtLegalCopyright.FillColor = System.Drawing.Color.Black;
            this.txtLegalCopyright.ForeColor = System.Drawing.Color.White;
            this.txtLegalCopyright.HideSelection = true;
            this.txtLegalCopyright.IconLeft = null;
            this.txtLegalCopyright.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLegalCopyright.IconPadding = 10;
            this.txtLegalCopyright.IconRight = null;
            this.txtLegalCopyright.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLegalCopyright.Lines = new string[0];
            this.txtLegalCopyright.Location = new System.Drawing.Point(124, 118);
            this.txtLegalCopyright.MaxLength = 32767;
            this.txtLegalCopyright.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtLegalCopyright.Modified = false;
            this.txtLegalCopyright.Multiline = false;
            this.txtLegalCopyright.Name = "txtLegalCopyright";
            stateProperties65.BorderColor = System.Drawing.Color.Transparent;
            stateProperties65.FillColor = System.Drawing.Color.Empty;
            stateProperties65.ForeColor = System.Drawing.Color.Empty;
            stateProperties65.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtLegalCopyright.OnActiveState = stateProperties65;
            stateProperties66.BorderColor = System.Drawing.Color.Silver;
            stateProperties66.FillColor = System.Drawing.Color.Black;
            stateProperties66.ForeColor = System.Drawing.Color.Transparent;
            stateProperties66.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.txtLegalCopyright.OnDisabledState = stateProperties66;
            stateProperties67.BorderColor = System.Drawing.Color.Transparent;
            stateProperties67.FillColor = System.Drawing.Color.Empty;
            stateProperties67.ForeColor = System.Drawing.Color.Empty;
            stateProperties67.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtLegalCopyright.OnHoverState = stateProperties67;
            stateProperties68.BorderColor = System.Drawing.Color.Silver;
            stateProperties68.FillColor = System.Drawing.Color.Black;
            stateProperties68.ForeColor = System.Drawing.Color.White;
            stateProperties68.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtLegalCopyright.OnIdleState = stateProperties68;
            this.txtLegalCopyright.Padding = new System.Windows.Forms.Padding(3);
            this.txtLegalCopyright.PasswordChar = '\0';
            this.txtLegalCopyright.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.txtLegalCopyright.PlaceholderText = " © 2024 Google Inc.";
            this.txtLegalCopyright.ReadOnly = false;
            this.txtLegalCopyright.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtLegalCopyright.SelectedText = "";
            this.txtLegalCopyright.SelectionLength = 0;
            this.txtLegalCopyright.SelectionStart = 0;
            this.txtLegalCopyright.ShortcutsEnabled = true;
            this.txtLegalCopyright.Size = new System.Drawing.Size(297, 24);
            this.txtLegalCopyright.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtLegalCopyright.TabIndex = 21;
            this.txtLegalCopyright.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtLegalCopyright.TextMarginBottom = 0;
            this.txtLegalCopyright.TextMarginLeft = 3;
            this.txtLegalCopyright.TextMarginTop = 0;
            this.txtLegalCopyright.TextPlaceholder = " © 2024 Google Inc.";
            this.txtLegalCopyright.UseSystemPasswordChar = false;
            this.txtLegalCopyright.WordWrap = true;
            // 
            // bunifuLabel5
            // 
            this.bunifuLabel5.AllowParentOverrides = false;
            this.bunifuLabel5.AutoEllipsis = false;
            this.bunifuLabel5.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel5.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel5.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel5.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel5.Location = new System.Drawing.Point(9, 88);
            this.bunifuLabel5.Name = "bunifuLabel5";
            this.bunifuLabel5.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel5.Size = new System.Drawing.Size(87, 17);
            this.bunifuLabel5.TabIndex = 18;
            this.bunifuLabel5.Text = "Product Name:";
            this.bunifuLabel5.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel5.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtProductName
            // 
            this.txtProductName.AcceptsReturn = false;
            this.txtProductName.AcceptsTab = false;
            this.txtProductName.AnimationSpeed = 200;
            this.txtProductName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtProductName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtProductName.BackColor = System.Drawing.Color.White;
            this.txtProductName.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtProductName.BackgroundImage")));
            this.txtProductName.BorderColorActive = System.Drawing.Color.Transparent;
            this.txtProductName.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtProductName.BorderColorHover = System.Drawing.Color.Transparent;
            this.txtProductName.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtProductName.BorderRadius = 1;
            this.txtProductName.BorderThickness = 1;
            this.txtProductName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtProductName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtProductName.DefaultFont = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtProductName.DefaultText = "";
            this.txtProductName.FillColor = System.Drawing.Color.Black;
            this.txtProductName.ForeColor = System.Drawing.Color.White;
            this.txtProductName.HideSelection = true;
            this.txtProductName.IconLeft = null;
            this.txtProductName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtProductName.IconPadding = 10;
            this.txtProductName.IconRight = null;
            this.txtProductName.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtProductName.Lines = new string[0];
            this.txtProductName.Location = new System.Drawing.Point(124, 88);
            this.txtProductName.MaxLength = 32767;
            this.txtProductName.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtProductName.Modified = false;
            this.txtProductName.Multiline = false;
            this.txtProductName.Name = "txtProductName";
            stateProperties69.BorderColor = System.Drawing.Color.Transparent;
            stateProperties69.FillColor = System.Drawing.Color.Empty;
            stateProperties69.ForeColor = System.Drawing.Color.Empty;
            stateProperties69.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtProductName.OnActiveState = stateProperties69;
            stateProperties70.BorderColor = System.Drawing.Color.Silver;
            stateProperties70.FillColor = System.Drawing.Color.Black;
            stateProperties70.ForeColor = System.Drawing.Color.Transparent;
            stateProperties70.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.txtProductName.OnDisabledState = stateProperties70;
            stateProperties71.BorderColor = System.Drawing.Color.Transparent;
            stateProperties71.FillColor = System.Drawing.Color.Empty;
            stateProperties71.ForeColor = System.Drawing.Color.Empty;
            stateProperties71.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtProductName.OnHoverState = stateProperties71;
            stateProperties72.BorderColor = System.Drawing.Color.Silver;
            stateProperties72.FillColor = System.Drawing.Color.Black;
            stateProperties72.ForeColor = System.Drawing.Color.White;
            stateProperties72.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtProductName.OnIdleState = stateProperties72;
            this.txtProductName.Padding = new System.Windows.Forms.Padding(3);
            this.txtProductName.PasswordChar = '\0';
            this.txtProductName.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.txtProductName.PlaceholderText = "Google Chrome";
            this.txtProductName.ReadOnly = false;
            this.txtProductName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtProductName.SelectedText = "";
            this.txtProductName.SelectionLength = 0;
            this.txtProductName.SelectionStart = 0;
            this.txtProductName.ShortcutsEnabled = true;
            this.txtProductName.Size = new System.Drawing.Size(297, 24);
            this.txtProductName.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtProductName.TabIndex = 19;
            this.txtProductName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtProductName.TextMarginBottom = 0;
            this.txtProductName.TextMarginLeft = 3;
            this.txtProductName.TextMarginTop = 0;
            this.txtProductName.TextPlaceholder = "Google Chrome";
            this.txtProductName.UseSystemPasswordChar = false;
            this.txtProductName.WordWrap = true;
            // 
            // bunifuLabel3
            // 
            this.bunifuLabel3.AllowParentOverrides = false;
            this.bunifuLabel3.AutoEllipsis = false;
            this.bunifuLabel3.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel3.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel3.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel3.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel3.Location = new System.Drawing.Point(9, 52);
            this.bunifuLabel3.Name = "bunifuLabel3";
            this.bunifuLabel3.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel3.Size = new System.Drawing.Size(92, 17);
            this.bunifuLabel3.TabIndex = 16;
            this.bunifuLabel3.Text = "File Description:";
            this.bunifuLabel3.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel3.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtFileDescription
            // 
            this.txtFileDescription.AcceptsReturn = false;
            this.txtFileDescription.AcceptsTab = false;
            this.txtFileDescription.AnimationSpeed = 200;
            this.txtFileDescription.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtFileDescription.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtFileDescription.BackColor = System.Drawing.Color.White;
            this.txtFileDescription.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtFileDescription.BackgroundImage")));
            this.txtFileDescription.BorderColorActive = System.Drawing.Color.Transparent;
            this.txtFileDescription.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtFileDescription.BorderColorHover = System.Drawing.Color.Transparent;
            this.txtFileDescription.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtFileDescription.BorderRadius = 1;
            this.txtFileDescription.BorderThickness = 1;
            this.txtFileDescription.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtFileDescription.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtFileDescription.DefaultFont = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtFileDescription.DefaultText = "";
            this.txtFileDescription.FillColor = System.Drawing.Color.Black;
            this.txtFileDescription.ForeColor = System.Drawing.Color.White;
            this.txtFileDescription.HideSelection = true;
            this.txtFileDescription.IconLeft = null;
            this.txtFileDescription.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtFileDescription.IconPadding = 10;
            this.txtFileDescription.IconRight = null;
            this.txtFileDescription.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtFileDescription.Lines = new string[0];
            this.txtFileDescription.Location = new System.Drawing.Point(124, 49);
            this.txtFileDescription.MaxLength = 32767;
            this.txtFileDescription.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtFileDescription.Modified = false;
            this.txtFileDescription.Multiline = false;
            this.txtFileDescription.Name = "txtFileDescription";
            stateProperties73.BorderColor = System.Drawing.Color.Transparent;
            stateProperties73.FillColor = System.Drawing.Color.Empty;
            stateProperties73.ForeColor = System.Drawing.Color.Empty;
            stateProperties73.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtFileDescription.OnActiveState = stateProperties73;
            stateProperties74.BorderColor = System.Drawing.Color.Silver;
            stateProperties74.FillColor = System.Drawing.Color.Black;
            stateProperties74.ForeColor = System.Drawing.Color.Transparent;
            stateProperties74.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.txtFileDescription.OnDisabledState = stateProperties74;
            stateProperties75.BorderColor = System.Drawing.Color.Transparent;
            stateProperties75.FillColor = System.Drawing.Color.Empty;
            stateProperties75.ForeColor = System.Drawing.Color.Empty;
            stateProperties75.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtFileDescription.OnHoverState = stateProperties75;
            stateProperties76.BorderColor = System.Drawing.Color.Silver;
            stateProperties76.FillColor = System.Drawing.Color.Black;
            stateProperties76.ForeColor = System.Drawing.Color.White;
            stateProperties76.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtFileDescription.OnIdleState = stateProperties76;
            this.txtFileDescription.Padding = new System.Windows.Forms.Padding(3);
            this.txtFileDescription.PasswordChar = '\0';
            this.txtFileDescription.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.txtFileDescription.PlaceholderText = "Google Updater";
            this.txtFileDescription.ReadOnly = false;
            this.txtFileDescription.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtFileDescription.SelectedText = "";
            this.txtFileDescription.SelectionLength = 0;
            this.txtFileDescription.SelectionStart = 0;
            this.txtFileDescription.ShortcutsEnabled = true;
            this.txtFileDescription.Size = new System.Drawing.Size(297, 24);
            this.txtFileDescription.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtFileDescription.TabIndex = 17;
            this.txtFileDescription.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtFileDescription.TextMarginBottom = 0;
            this.txtFileDescription.TextMarginLeft = 3;
            this.txtFileDescription.TextMarginTop = 0;
            this.txtFileDescription.TextPlaceholder = "Google Updater";
            this.txtFileDescription.UseSystemPasswordChar = false;
            this.txtFileDescription.WordWrap = true;
            // 
            // btnCancel
            // 
            this.btnCancel.AllowAnimations = true;
            this.btnCancel.AllowMouseEffects = true;
            this.btnCancel.AllowToggling = false;
            this.btnCancel.AnimationSpeed = 200;
            this.btnCancel.AutoGenerateColors = false;
            this.btnCancel.AutoRoundBorders = false;
            this.btnCancel.AutoSizeLeftIcon = true;
            this.btnCancel.AutoSizeRightIcon = true;
            this.btnCancel.BackColor = System.Drawing.Color.Transparent;
            this.btnCancel.BackColor1 = System.Drawing.Color.Transparent;
            this.btnCancel.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCancel.BackgroundImage")));
            this.btnCancel.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnCancel.ButtonText = "Cancel";
            this.btnCancel.ButtonTextMarginLeft = 0;
            this.btnCancel.ColorContrastOnClick = 45;
            this.btnCancel.ColorContrastOnHover = 45;
            this.btnCancel.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges5.BottomLeft = true;
            borderEdges5.BottomRight = true;
            borderEdges5.TopLeft = true;
            borderEdges5.TopRight = true;
            this.btnCancel.CustomizableEdges = borderEdges5;
            this.btnCancel.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnCancel.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnCancel.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnCancel.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnCancel.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Idle;
            this.btnCancel.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnCancel.ForeColor = System.Drawing.Color.White;
            this.btnCancel.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCancel.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnCancel.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnCancel.IconMarginLeft = 11;
            this.btnCancel.IconPadding = 10;
            this.btnCancel.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCancel.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnCancel.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnCancel.IconSize = 25;
            this.btnCancel.IdleBorderColor = System.Drawing.Color.White;
            this.btnCancel.IdleBorderRadius = 1;
            this.btnCancel.IdleBorderThickness = 1;
            this.btnCancel.IdleFillColor = System.Drawing.Color.Transparent;
            this.btnCancel.IdleIconLeftImage = null;
            this.btnCancel.IdleIconRightImage = null;
            this.btnCancel.IndicateFocus = false;
            this.btnCancel.Location = new System.Drawing.Point(313, 269);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnCancel.OnDisabledState.BorderRadius = 1;
            this.btnCancel.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnCancel.OnDisabledState.BorderThickness = 1;
            this.btnCancel.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnCancel.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnCancel.OnDisabledState.IconLeftImage = null;
            this.btnCancel.OnDisabledState.IconRightImage = null;
            this.btnCancel.onHoverState.BorderColor = System.Drawing.Color.White;
            this.btnCancel.onHoverState.BorderRadius = 1;
            this.btnCancel.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnCancel.onHoverState.BorderThickness = 1;
            this.btnCancel.onHoverState.FillColor = System.Drawing.Color.Gray;
            this.btnCancel.onHoverState.ForeColor = System.Drawing.Color.Transparent;
            this.btnCancel.onHoverState.IconLeftImage = null;
            this.btnCancel.onHoverState.IconRightImage = null;
            this.btnCancel.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.btnCancel.OnIdleState.BorderRadius = 1;
            this.btnCancel.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnCancel.OnIdleState.BorderThickness = 1;
            this.btnCancel.OnIdleState.FillColor = System.Drawing.Color.Transparent;
            this.btnCancel.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnCancel.OnIdleState.IconLeftImage = null;
            this.btnCancel.OnIdleState.IconRightImage = null;
            this.btnCancel.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.btnCancel.OnPressedState.BorderRadius = 1;
            this.btnCancel.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnCancel.OnPressedState.BorderThickness = 1;
            this.btnCancel.OnPressedState.FillColor = System.Drawing.Color.Gray;
            this.btnCancel.OnPressedState.ForeColor = System.Drawing.Color.Transparent;
            this.btnCancel.OnPressedState.IconLeftImage = null;
            this.btnCancel.OnPressedState.IconRightImage = null;
            this.btnCancel.Size = new System.Drawing.Size(63, 32);
            this.btnCancel.TabIndex = 11;
            this.btnCancel.TabStop = false;
            this.btnCancel.Tag = "NoIcon";
            this.btnCancel.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnCancel.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnCancel.TextMarginLeft = 0;
            this.btnCancel.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnCancel.UseDefaultRadiusAndThickness = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click);
            // 
            // bunifuLabel6
            // 
            this.bunifuLabel6.AllowParentOverrides = false;
            this.bunifuLabel6.AutoEllipsis = false;
            this.bunifuLabel6.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel6.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel6.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel6.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel6.Location = new System.Drawing.Point(9, 156);
            this.bunifuLabel6.Name = "bunifuLabel6";
            this.bunifuLabel6.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel6.Size = new System.Drawing.Size(107, 17);
            this.bunifuLabel6.TabIndex = 14;
            this.bunifuLabel6.Text = "Legal Trademarks:";
            this.bunifuLabel6.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel6.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // btnOk
            // 
            this.btnOk.AllowAnimations = true;
            this.btnOk.AllowMouseEffects = true;
            this.btnOk.AllowToggling = false;
            this.btnOk.AnimationSpeed = 200;
            this.btnOk.AutoGenerateColors = false;
            this.btnOk.AutoRoundBorders = false;
            this.btnOk.AutoSizeLeftIcon = true;
            this.btnOk.AutoSizeRightIcon = true;
            this.btnOk.BackColor = System.Drawing.Color.Transparent;
            this.btnOk.BackColor1 = System.Drawing.Color.Transparent;
            this.btnOk.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnOk.BackgroundImage")));
            this.btnOk.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnOk.ButtonText = "Ok";
            this.btnOk.ButtonTextMarginLeft = 0;
            this.btnOk.ColorContrastOnClick = 45;
            this.btnOk.ColorContrastOnHover = 45;
            this.btnOk.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges6.BottomLeft = true;
            borderEdges6.BottomRight = true;
            borderEdges6.TopLeft = true;
            borderEdges6.TopRight = true;
            this.btnOk.CustomizableEdges = borderEdges6;
            this.btnOk.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnOk.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnOk.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnOk.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnOk.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Idle;
            this.btnOk.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnOk.ForeColor = System.Drawing.Color.White;
            this.btnOk.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnOk.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnOk.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnOk.IconMarginLeft = 11;
            this.btnOk.IconPadding = 10;
            this.btnOk.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnOk.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnOk.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnOk.IconSize = 25;
            this.btnOk.IdleBorderColor = System.Drawing.Color.White;
            this.btnOk.IdleBorderRadius = 1;
            this.btnOk.IdleBorderThickness = 1;
            this.btnOk.IdleFillColor = System.Drawing.Color.Transparent;
            this.btnOk.IdleIconLeftImage = null;
            this.btnOk.IdleIconRightImage = null;
            this.btnOk.IndicateFocus = false;
            this.btnOk.Location = new System.Drawing.Point(382, 269);
            this.btnOk.Name = "btnOk";
            this.btnOk.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnOk.OnDisabledState.BorderRadius = 1;
            this.btnOk.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnOk.OnDisabledState.BorderThickness = 1;
            this.btnOk.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnOk.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnOk.OnDisabledState.IconLeftImage = null;
            this.btnOk.OnDisabledState.IconRightImage = null;
            this.btnOk.onHoverState.BorderColor = System.Drawing.Color.White;
            this.btnOk.onHoverState.BorderRadius = 1;
            this.btnOk.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnOk.onHoverState.BorderThickness = 1;
            this.btnOk.onHoverState.FillColor = System.Drawing.Color.Gray;
            this.btnOk.onHoverState.ForeColor = System.Drawing.Color.Transparent;
            this.btnOk.onHoverState.IconLeftImage = null;
            this.btnOk.onHoverState.IconRightImage = null;
            this.btnOk.OnIdleState.BorderColor = System.Drawing.Color.White;
            this.btnOk.OnIdleState.BorderRadius = 1;
            this.btnOk.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnOk.OnIdleState.BorderThickness = 1;
            this.btnOk.OnIdleState.FillColor = System.Drawing.Color.Transparent;
            this.btnOk.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnOk.OnIdleState.IconLeftImage = null;
            this.btnOk.OnIdleState.IconRightImage = null;
            this.btnOk.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.btnOk.OnPressedState.BorderRadius = 1;
            this.btnOk.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnOk.OnPressedState.BorderThickness = 1;
            this.btnOk.OnPressedState.FillColor = System.Drawing.Color.Gray;
            this.btnOk.OnPressedState.ForeColor = System.Drawing.Color.Transparent;
            this.btnOk.OnPressedState.IconLeftImage = null;
            this.btnOk.OnPressedState.IconRightImage = null;
            this.btnOk.Size = new System.Drawing.Size(39, 32);
            this.btnOk.TabIndex = 12;
            this.btnOk.TabStop = false;
            this.btnOk.Tag = "NoIcon";
            this.btnOk.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnOk.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnOk.TextMarginLeft = 0;
            this.btnOk.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnOk.UseDefaultRadiusAndThickness = true;
            this.btnOk.Click += new System.EventHandler(this.btnOk_Click);
            // 
            // txtLegalTrademarks
            // 
            this.txtLegalTrademarks.AcceptsReturn = false;
            this.txtLegalTrademarks.AcceptsTab = false;
            this.txtLegalTrademarks.AnimationSpeed = 200;
            this.txtLegalTrademarks.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtLegalTrademarks.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtLegalTrademarks.BackColor = System.Drawing.Color.White;
            this.txtLegalTrademarks.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtLegalTrademarks.BackgroundImage")));
            this.txtLegalTrademarks.BorderColorActive = System.Drawing.Color.Transparent;
            this.txtLegalTrademarks.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtLegalTrademarks.BorderColorHover = System.Drawing.Color.Transparent;
            this.txtLegalTrademarks.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtLegalTrademarks.BorderRadius = 1;
            this.txtLegalTrademarks.BorderThickness = 1;
            this.txtLegalTrademarks.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtLegalTrademarks.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLegalTrademarks.DefaultFont = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtLegalTrademarks.DefaultText = "";
            this.txtLegalTrademarks.FillColor = System.Drawing.Color.Black;
            this.txtLegalTrademarks.ForeColor = System.Drawing.Color.White;
            this.txtLegalTrademarks.HideSelection = true;
            this.txtLegalTrademarks.IconLeft = null;
            this.txtLegalTrademarks.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLegalTrademarks.IconPadding = 10;
            this.txtLegalTrademarks.IconRight = null;
            this.txtLegalTrademarks.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtLegalTrademarks.Lines = new string[0];
            this.txtLegalTrademarks.Location = new System.Drawing.Point(124, 153);
            this.txtLegalTrademarks.MaxLength = 32767;
            this.txtLegalTrademarks.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtLegalTrademarks.Modified = false;
            this.txtLegalTrademarks.Multiline = false;
            this.txtLegalTrademarks.Name = "txtLegalTrademarks";
            stateProperties77.BorderColor = System.Drawing.Color.Transparent;
            stateProperties77.FillColor = System.Drawing.Color.Empty;
            stateProperties77.ForeColor = System.Drawing.Color.Empty;
            stateProperties77.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtLegalTrademarks.OnActiveState = stateProperties77;
            stateProperties78.BorderColor = System.Drawing.Color.Silver;
            stateProperties78.FillColor = System.Drawing.Color.Black;
            stateProperties78.ForeColor = System.Drawing.Color.Transparent;
            stateProperties78.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.txtLegalTrademarks.OnDisabledState = stateProperties78;
            stateProperties79.BorderColor = System.Drawing.Color.Transparent;
            stateProperties79.FillColor = System.Drawing.Color.Empty;
            stateProperties79.ForeColor = System.Drawing.Color.Empty;
            stateProperties79.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtLegalTrademarks.OnHoverState = stateProperties79;
            stateProperties80.BorderColor = System.Drawing.Color.Silver;
            stateProperties80.FillColor = System.Drawing.Color.Black;
            stateProperties80.ForeColor = System.Drawing.Color.White;
            stateProperties80.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtLegalTrademarks.OnIdleState = stateProperties80;
            this.txtLegalTrademarks.Padding = new System.Windows.Forms.Padding(3);
            this.txtLegalTrademarks.PasswordChar = '\0';
            this.txtLegalTrademarks.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.txtLegalTrademarks.PlaceholderText = "Google Chrome is a trademark of Google, Inc.";
            this.txtLegalTrademarks.ReadOnly = false;
            this.txtLegalTrademarks.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtLegalTrademarks.SelectedText = "";
            this.txtLegalTrademarks.SelectionLength = 0;
            this.txtLegalTrademarks.SelectionStart = 0;
            this.txtLegalTrademarks.ShortcutsEnabled = true;
            this.txtLegalTrademarks.Size = new System.Drawing.Size(297, 24);
            this.txtLegalTrademarks.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtLegalTrademarks.TabIndex = 15;
            this.txtLegalTrademarks.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtLegalTrademarks.TextMarginBottom = 0;
            this.txtLegalTrademarks.TextMarginLeft = 3;
            this.txtLegalTrademarks.TextMarginTop = 0;
            this.txtLegalTrademarks.TextPlaceholder = "Google Chrome is a trademark of Google, Inc.";
            this.txtLegalTrademarks.UseSystemPasswordChar = false;
            this.txtLegalTrademarks.WordWrap = true;
            // 
            // bunifuLabel2
            // 
            this.bunifuLabel2.AllowParentOverrides = false;
            this.bunifuLabel2.AutoEllipsis = false;
            this.bunifuLabel2.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel2.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel2.Font = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel2.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel2.Location = new System.Drawing.Point(9, 19);
            this.bunifuLabel2.Name = "bunifuLabel2";
            this.bunifuLabel2.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel2.Size = new System.Drawing.Size(97, 17);
            this.bunifuLabel2.TabIndex = 14;
            this.bunifuLabel2.Text = "Company Name:";
            this.bunifuLabel2.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.bunifuLabel2.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // txtCompanyName
            // 
            this.txtCompanyName.AcceptsReturn = false;
            this.txtCompanyName.AcceptsTab = false;
            this.txtCompanyName.AnimationSpeed = 200;
            this.txtCompanyName.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtCompanyName.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtCompanyName.BackColor = System.Drawing.Color.White;
            this.txtCompanyName.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtCompanyName.BackgroundImage")));
            this.txtCompanyName.BorderColorActive = System.Drawing.Color.Transparent;
            this.txtCompanyName.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtCompanyName.BorderColorHover = System.Drawing.Color.Transparent;
            this.txtCompanyName.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtCompanyName.BorderRadius = 1;
            this.txtCompanyName.BorderThickness = 1;
            this.txtCompanyName.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtCompanyName.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCompanyName.DefaultFont = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtCompanyName.DefaultText = "";
            this.txtCompanyName.FillColor = System.Drawing.Color.Black;
            this.txtCompanyName.ForeColor = System.Drawing.Color.White;
            this.txtCompanyName.HideSelection = true;
            this.txtCompanyName.IconLeft = null;
            this.txtCompanyName.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCompanyName.IconPadding = 10;
            this.txtCompanyName.IconRight = null;
            this.txtCompanyName.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtCompanyName.Lines = new string[0];
            this.txtCompanyName.Location = new System.Drawing.Point(124, 16);
            this.txtCompanyName.MaxLength = 32767;
            this.txtCompanyName.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtCompanyName.Modified = false;
            this.txtCompanyName.Multiline = false;
            this.txtCompanyName.Name = "txtCompanyName";
            stateProperties81.BorderColor = System.Drawing.Color.Transparent;
            stateProperties81.FillColor = System.Drawing.Color.Empty;
            stateProperties81.ForeColor = System.Drawing.Color.Empty;
            stateProperties81.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCompanyName.OnActiveState = stateProperties81;
            stateProperties82.BorderColor = System.Drawing.Color.Silver;
            stateProperties82.FillColor = System.Drawing.Color.Black;
            stateProperties82.ForeColor = System.Drawing.Color.Transparent;
            stateProperties82.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.txtCompanyName.OnDisabledState = stateProperties82;
            stateProperties83.BorderColor = System.Drawing.Color.Transparent;
            stateProperties83.FillColor = System.Drawing.Color.Empty;
            stateProperties83.ForeColor = System.Drawing.Color.Empty;
            stateProperties83.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCompanyName.OnHoverState = stateProperties83;
            stateProperties84.BorderColor = System.Drawing.Color.Silver;
            stateProperties84.FillColor = System.Drawing.Color.Black;
            stateProperties84.ForeColor = System.Drawing.Color.White;
            stateProperties84.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtCompanyName.OnIdleState = stateProperties84;
            this.txtCompanyName.Padding = new System.Windows.Forms.Padding(3);
            this.txtCompanyName.PasswordChar = '\0';
            this.txtCompanyName.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.txtCompanyName.PlaceholderText = "Google inc";
            this.txtCompanyName.ReadOnly = false;
            this.txtCompanyName.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtCompanyName.SelectedText = "";
            this.txtCompanyName.SelectionLength = 0;
            this.txtCompanyName.SelectionStart = 0;
            this.txtCompanyName.ShortcutsEnabled = true;
            this.txtCompanyName.Size = new System.Drawing.Size(297, 24);
            this.txtCompanyName.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtCompanyName.TabIndex = 15;
            this.txtCompanyName.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtCompanyName.TextMarginBottom = 0;
            this.txtCompanyName.TextMarginLeft = 3;
            this.txtCompanyName.TextMarginTop = 0;
            this.txtCompanyName.TextPlaceholder = "Google inc";
            this.txtCompanyName.UseSystemPasswordChar = false;
            this.txtCompanyName.WordWrap = true;
            // 
            // AssemblyEditorForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(486, 365);
            this.Controls.Add(this.bunifuShadowPanel1);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "AssemblyEditorForm";
            this.Padding = new System.Windows.Forms.Padding(2);
            this.ShowIcon = false;
            this.ShowInTaskbar = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "AssemblyEditor";
            this.Shown += new System.EventHandler(this.AssemblyEditorForm_Shown);
            this.panel1.ResumeLayout(false);
            this.panel1.PerformLayout();
            this.bunifuShadowPanel1.ResumeLayout(false);
            this.bunifuShadowPanel1.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion

        private Bunifu.Framework.UI.BunifuElipse bunifuElipse1;
        private System.Windows.Forms.Panel panel1;
        private Bunifu.UI.WinForms.BunifuColorTransition bunifuColorTransition1;
        private Bunifu.UI.WinForms.BunifuShadowPanel bunifuShadowPanel1;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnCancel;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnOk;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel2;
        private Bunifu.UI.WinForms.BunifuTextBox txtCompanyName;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel9;
        private Bunifu.UI.WinForms.BunifuTextBox txtInternalName;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel10;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel4;
        private Bunifu.UI.WinForms.BunifuTextBox txtOriginalFilename;
        private Bunifu.UI.WinForms.BunifuTextBox txtLegalCopyright;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel5;
        private Bunifu.UI.WinForms.BunifuTextBox txtProductName;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel3;
        private Bunifu.UI.WinForms.BunifuTextBox txtFileDescription;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel6;
        private Bunifu.UI.WinForms.BunifuTextBox txtLegalTrademarks;
    }
}