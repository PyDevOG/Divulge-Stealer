﻿namespace Divulge.builder.Components.Forms
{
    partial class MainForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(MainForm));
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges9 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges10 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges11 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges borderEdges12 = new Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderEdges();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties9 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties10 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties11 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            Bunifu.UI.WinForms.BunifuTextBox.StateProperties stateProperties12 = new Bunifu.UI.WinForms.BunifuTextBox.StateProperties();
            this.panel1 = new System.Windows.Forms.Panel();
            this.bunifuLabel1 = new Bunifu.UI.WinForms.BunifuLabel();
            this.buttonMinimize = new System.Windows.Forms.Button();
            this.buttonClose = new System.Windows.Forms.Button();
            this.bunifuColorTransition1 = new Bunifu.UI.WinForms.BunifuColorTransition(this.components);
            this.bunifuElipse2 = new Bunifu.Framework.UI.BunifuElipse(this.components);
            this.panel2 = new System.Windows.Forms.Panel();
            this.bunifuShadowPanel2 = new Bunifu.UI.WinForms.BunifuShadowPanel();
            this.label1 = new System.Windows.Forms.Label();
            this.grpOptions = new System.Windows.Forms.GroupBox();
            this.labelWallets = new Bunifu.UI.WinForms.BunifuLabel();
            this.chkWallets = new Bunifu.UI.WinForms.BunifuCheckBox();
            this.labelScreenshot = new Bunifu.UI.WinForms.BunifuLabel();
            this.chklSystemInfo = new Bunifu.UI.WinForms.BunifuLabel();
            this.chkScreenshot = new Bunifu.UI.WinForms.BunifuCheckBox();
            this.chkSystemInfo = new Bunifu.UI.WinForms.BunifuCheckBox();
            this.labelBrowserCookies = new Bunifu.UI.WinForms.BunifuLabel();
            this.chkCookies = new Bunifu.UI.WinForms.BunifuCheckBox();
            this.labelBrowserPasswords = new Bunifu.UI.WinForms.BunifuLabel();
            this.chkPasswords = new Bunifu.UI.WinForms.BunifuCheckBox();
            this.labelDiscordTokens = new Bunifu.UI.WinForms.BunifuLabel();
            this.chkDiscord = new Bunifu.UI.WinForms.BunifuCheckBox();
            this.btnModifyAssembly = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.txtVersion = new Bunifu.UI.WinForms.BunifuLabel();
            this.btnIconSelect = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnBuild = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.btnCheckWebhook = new Bunifu.UI.WinForms.BunifuButton.BunifuButton();
            this.grpBasic = new System.Windows.Forms.GroupBox();
            this.labelBlockAvSites = new Bunifu.UI.WinForms.BunifuLabel();
            this.chkBlockAvSites = new Bunifu.UI.WinForms.BunifuCheckBox();
            this.labelMelt = new Bunifu.UI.WinForms.BunifuLabel();
            this.chkMelt = new Bunifu.UI.WinForms.BunifuCheckBox();
            this.labelAntiVm = new Bunifu.UI.WinForms.BunifuLabel();
            this.chkAntiVm = new Bunifu.UI.WinForms.BunifuCheckBox();
            this.labelAddToStartup = new Bunifu.UI.WinForms.BunifuLabel();
            this.chkStartup = new Bunifu.UI.WinForms.BunifuCheckBox();
            this.txtWebhook = new Bunifu.UI.WinForms.BunifuTextBox();
            this.panel1.SuspendLayout();
            this.panel2.SuspendLayout();
            this.bunifuShadowPanel2.SuspendLayout();
            this.grpOptions.SuspendLayout();
            this.grpBasic.SuspendLayout();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.BackColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.panel1.Controls.Add(this.bunifuLabel1);
            this.panel1.Controls.Add(this.buttonMinimize);
            this.panel1.Controls.Add(this.buttonClose);
            this.panel1.Dock = System.Windows.Forms.DockStyle.Top;
            this.panel1.Font = new System.Drawing.Font("Yu Gothic UI", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(2, 2);
            this.panel1.Name = "panel1";
            this.panel1.Padding = new System.Windows.Forms.Padding(0, 0, 5, 0);
            this.panel1.Size = new System.Drawing.Size(629, 31);
            this.panel1.TabIndex = 0;
            this.panel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Drag_On_Mousedown);
            // 
            // bunifuLabel1
            // 
            this.bunifuLabel1.AllowParentOverrides = false;
            this.bunifuLabel1.AutoEllipsis = true;
            this.bunifuLabel1.AutoSize = false;
            this.bunifuLabel1.Cursor = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.CursorType = System.Windows.Forms.Cursors.Default;
            this.bunifuLabel1.Font = new System.Drawing.Font("Yu Gothic UI", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.bunifuLabel1.ForeColor = System.Drawing.Color.White;
            this.bunifuLabel1.Location = new System.Drawing.Point(197, 3);
            this.bunifuLabel1.Name = "bunifuLabel1";
            this.bunifuLabel1.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.bunifuLabel1.Size = new System.Drawing.Size(224, 25);
            this.bunifuLabel1.TabIndex = 3;
            this.bunifuLabel1.Text = "Divulge Stealer v2.0 ";
            this.bunifuLabel1.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.bunifuLabel1.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            this.bunifuLabel1.Click += new System.EventHandler(this.bunifuLabel1_Click);
            this.bunifuLabel1.MouseDown += new System.Windows.Forms.MouseEventHandler(this.Drag_On_Mousedown);
            // 
            // buttonMinimize
            // 
            this.buttonMinimize.BackgroundImage = global::Divulge.builder.Properties.Resources.fluent_emoji_flat_yellow_circle;
            this.buttonMinimize.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonMinimize.Dock = System.Windows.Forms.DockStyle.Right;
            this.buttonMinimize.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.buttonMinimize.FlatAppearance.BorderSize = 0;
            this.buttonMinimize.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.buttonMinimize.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.buttonMinimize.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonMinimize.ForeColor = System.Drawing.Color.Transparent;
            this.buttonMinimize.Location = new System.Drawing.Point(580, 0);
            this.buttonMinimize.Name = "buttonMinimize";
            this.buttonMinimize.Size = new System.Drawing.Size(22, 31);
            this.buttonMinimize.TabIndex = 2;
            this.buttonMinimize.TabStop = false;
            this.buttonMinimize.UseVisualStyleBackColor = true;
            this.buttonMinimize.Click += new System.EventHandler(this.buttonMinimize_Click);
            // 
            // buttonClose
            // 
            this.buttonClose.BackColor = System.Drawing.Color.Transparent;
            this.buttonClose.BackgroundImage = global::Divulge.builder.Properties.Resources.fluent_emoji_flat_red_circle;
            this.buttonClose.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.buttonClose.Dock = System.Windows.Forms.DockStyle.Right;
            this.buttonClose.FlatAppearance.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(21)))), ((int)(((byte)(21)))), ((int)(((byte)(21)))));
            this.buttonClose.FlatAppearance.BorderSize = 0;
            this.buttonClose.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Transparent;
            this.buttonClose.FlatAppearance.MouseOverBackColor = System.Drawing.Color.Transparent;
            this.buttonClose.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.buttonClose.ForeColor = System.Drawing.Color.Transparent;
            this.buttonClose.Location = new System.Drawing.Point(602, 0);
            this.buttonClose.Name = "buttonClose";
            this.buttonClose.Size = new System.Drawing.Size(22, 31);
            this.buttonClose.TabIndex = 1;
            this.buttonClose.TabStop = false;
            this.buttonClose.UseVisualStyleBackColor = false;
            this.buttonClose.Click += new System.EventHandler(this.buttonClose_Click);
            // 
            // bunifuColorTransition1
            // 
            this.bunifuColorTransition1.AutoTransition = false;
            this.bunifuColorTransition1.ColorArray = new System.Drawing.Color[] {
        System.Drawing.Color.Red,
        System.Drawing.Color.FromArgb(((int)(((byte)(255)))), ((int)(((byte)(128)))), ((int)(((byte)(0))))),
        System.Drawing.Color.Yellow,
        System.Drawing.Color.Lime,
        System.Drawing.Color.Aqua,
        System.Drawing.Color.Indigo,
        System.Drawing.Color.Purple};
            this.bunifuColorTransition1.EndColor = System.Drawing.Color.White;
            this.bunifuColorTransition1.Interval = 1;
            this.bunifuColorTransition1.ProgessValue = 0;
            this.bunifuColorTransition1.StartColor = System.Drawing.Color.White;
            this.bunifuColorTransition1.TransitionControl = this;
            // 
            // bunifuElipse2
            // 
            this.bunifuElipse2.ElipseRadius = 5;
            this.bunifuElipse2.TargetControl = this;
            // 
            // panel2
            // 
            this.panel2.Controls.Add(this.bunifuShadowPanel2);
            this.panel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.panel2.ForeColor = System.Drawing.Color.Transparent;
            this.panel2.Location = new System.Drawing.Point(2, 33);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(629, 429);
            this.panel2.TabIndex = 2;
            // 
            // bunifuShadowPanel2
            // 
            this.bunifuShadowPanel2.BackColor = System.Drawing.Color.Transparent;
            this.bunifuShadowPanel2.BorderColor = System.Drawing.Color.Transparent;
            this.bunifuShadowPanel2.BorderRadius = 0;
            this.bunifuShadowPanel2.BorderThickness = 1;
            this.bunifuShadowPanel2.Controls.Add(this.label1);
            this.bunifuShadowPanel2.Controls.Add(this.grpOptions);
            this.bunifuShadowPanel2.Controls.Add(this.btnModifyAssembly);
            this.bunifuShadowPanel2.Controls.Add(this.txtVersion);
            this.bunifuShadowPanel2.Controls.Add(this.btnIconSelect);
            this.bunifuShadowPanel2.Controls.Add(this.btnBuild);
            this.bunifuShadowPanel2.Controls.Add(this.btnCheckWebhook);
            this.bunifuShadowPanel2.Controls.Add(this.grpBasic);
            this.bunifuShadowPanel2.Controls.Add(this.txtWebhook);
            this.bunifuShadowPanel2.Dock = System.Windows.Forms.DockStyle.Fill;
            this.bunifuShadowPanel2.FillStyle = Bunifu.UI.WinForms.BunifuShadowPanel.FillStyles.Solid;
            this.bunifuShadowPanel2.GradientMode = Bunifu.UI.WinForms.BunifuShadowPanel.GradientModes.Vertical;
            this.bunifuShadowPanel2.Location = new System.Drawing.Point(0, 0);
            this.bunifuShadowPanel2.Name = "bunifuShadowPanel2";
            this.bunifuShadowPanel2.Padding = new System.Windows.Forms.Padding(2);
            this.bunifuShadowPanel2.PanelColor = System.Drawing.Color.Black;
            this.bunifuShadowPanel2.PanelColor2 = System.Drawing.Color.Black;
            this.bunifuShadowPanel2.ShadowColor = System.Drawing.Color.DarkGray;
            this.bunifuShadowPanel2.ShadowDept = 2;
            this.bunifuShadowPanel2.ShadowDepth = 0;
            this.bunifuShadowPanel2.ShadowStyle = Bunifu.UI.WinForms.BunifuShadowPanel.ShadowStyles.Dropped;
            this.bunifuShadowPanel2.ShadowTopLeftVisible = false;
            this.bunifuShadowPanel2.Size = new System.Drawing.Size(629, 429);
            this.bunifuShadowPanel2.Style = Bunifu.UI.WinForms.BunifuShadowPanel.BevelStyles.Flat;
            this.bunifuShadowPanel2.TabIndex = 1;
            this.bunifuShadowPanel2.ControlAdded += new System.Windows.Forms.ControlEventHandler(this.bunifuShadowPanel2_ControlAdded);
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Yu Gothic UI", 8.25F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.label1.ForeColor = System.Drawing.Color.Silver;
            this.label1.Location = new System.Drawing.Point(13, 12);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(92, 13);
            this.label1.TabIndex = 4;
            this.label1.Text = "Discord Webhook";
            // 
            // grpOptions
            // 
            this.grpOptions.BackColor = System.Drawing.Color.Black;
            this.grpOptions.Controls.Add(this.labelWallets);
            this.grpOptions.Controls.Add(this.chkWallets);
            this.grpOptions.Controls.Add(this.labelScreenshot);
            this.grpOptions.Controls.Add(this.chklSystemInfo);
            this.grpOptions.Controls.Add(this.chkScreenshot);
            this.grpOptions.Controls.Add(this.chkSystemInfo);
            this.grpOptions.Controls.Add(this.labelBrowserCookies);
            this.grpOptions.Controls.Add(this.chkCookies);
            this.grpOptions.Controls.Add(this.labelBrowserPasswords);
            this.grpOptions.Controls.Add(this.chkPasswords);
            this.grpOptions.Controls.Add(this.labelDiscordTokens);
            this.grpOptions.Controls.Add(this.chkDiscord);
            this.grpOptions.ForeColor = System.Drawing.Color.Silver;
            this.grpOptions.Location = new System.Drawing.Point(16, 70);
            this.grpOptions.Margin = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.grpOptions.Name = "grpOptions";
            this.grpOptions.Padding = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.grpOptions.Size = new System.Drawing.Size(378, 206);
            this.grpOptions.TabIndex = 3;
            this.grpOptions.TabStop = false;
            this.grpOptions.Text = "Stealer\'s";
            // 
            // labelWallets
            // 
            this.labelWallets.AccessibleRole = System.Windows.Forms.AccessibleRole.CheckButton;
            this.labelWallets.AllowParentOverrides = false;
            this.labelWallets.AutoEllipsis = false;
            this.labelWallets.Cursor = System.Windows.Forms.Cursors.Default;
            this.labelWallets.CursorType = System.Windows.Forms.Cursors.Default;
            this.labelWallets.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Italic);
            this.labelWallets.ForeColor = System.Drawing.Color.White;
            this.labelWallets.Location = new System.Drawing.Point(62, 35);
            this.labelWallets.Name = "labelWallets";
            this.labelWallets.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.labelWallets.Size = new System.Drawing.Size(51, 21);
            this.labelWallets.TabIndex = 12;
            this.labelWallets.Text = "Wallets";
            this.labelWallets.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.labelWallets.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // chkWallets
            // 
            this.chkWallets.AllowBindingControlAnimation = true;
            this.chkWallets.AllowBindingControlColorChanges = false;
            this.chkWallets.AllowBindingControlLocation = true;
            this.chkWallets.AllowCheckBoxAnimation = false;
            this.chkWallets.AllowCheckmarkAnimation = true;
            this.chkWallets.AllowOnHoverStates = true;
            this.chkWallets.AutoCheck = true;
            this.chkWallets.BackColor = System.Drawing.Color.Transparent;
            this.chkWallets.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chkWallets.BackgroundImage")));
            this.chkWallets.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.chkWallets.BindingControl = this.labelWallets;
            this.chkWallets.BindingControlPosition = Bunifu.UI.WinForms.BunifuCheckBox.BindingControlPositions.Right;
            this.chkWallets.BorderRadius = 5;
            this.chkWallets.Checked = true;
            this.chkWallets.CheckState = Bunifu.UI.WinForms.BunifuCheckBox.CheckStates.Checked;
            this.chkWallets.Cursor = System.Windows.Forms.Cursors.Default;
            this.chkWallets.CustomCheckmarkImage = null;
            this.chkWallets.Location = new System.Drawing.Point(38, 31);
            this.chkWallets.MinimumSize = new System.Drawing.Size(17, 17);
            this.chkWallets.Name = "chkWallets";
            this.chkWallets.OnCheck.BorderColor = System.Drawing.Color.White;
            this.chkWallets.OnCheck.BorderRadius = 5;
            this.chkWallets.OnCheck.BorderThickness = 2;
            this.chkWallets.OnCheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkWallets.OnCheck.CheckmarkColor = System.Drawing.Color.White;
            this.chkWallets.OnCheck.CheckmarkThickness = 2;
            this.chkWallets.OnDisable.BorderColor = System.Drawing.Color.LightGray;
            this.chkWallets.OnDisable.BorderRadius = 5;
            this.chkWallets.OnDisable.BorderThickness = 2;
            this.chkWallets.OnDisable.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkWallets.OnDisable.CheckmarkColor = System.Drawing.Color.LightGray;
            this.chkWallets.OnDisable.CheckmarkThickness = 2;
            this.chkWallets.OnHoverChecked.BorderColor = System.Drawing.Color.White;
            this.chkWallets.OnHoverChecked.BorderRadius = 5;
            this.chkWallets.OnHoverChecked.BorderThickness = 2;
            this.chkWallets.OnHoverChecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkWallets.OnHoverChecked.CheckmarkColor = System.Drawing.Color.White;
            this.chkWallets.OnHoverChecked.CheckmarkThickness = 2;
            this.chkWallets.OnHoverUnchecked.BorderColor = System.Drawing.Color.White;
            this.chkWallets.OnHoverUnchecked.BorderRadius = 5;
            this.chkWallets.OnHoverUnchecked.BorderThickness = 1;
            this.chkWallets.OnHoverUnchecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkWallets.OnUncheck.BorderColor = System.Drawing.Color.DarkGray;
            this.chkWallets.OnUncheck.BorderRadius = 5;
            this.chkWallets.OnUncheck.BorderThickness = 1;
            this.chkWallets.OnUncheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkWallets.Size = new System.Drawing.Size(21, 21);
            this.chkWallets.Style = Bunifu.UI.WinForms.BunifuCheckBox.CheckBoxStyles.Bunifu;
            this.chkWallets.TabIndex = 11;
            this.chkWallets.ThreeState = false;
            this.chkWallets.ToolTipText = null;
            this.chkWallets.CheckedChanged += new System.EventHandler<Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs>(this.CheckedChanged);
            // 
            // labelScreenshot
            // 
            this.labelScreenshot.AccessibleRole = System.Windows.Forms.AccessibleRole.CheckButton;
            this.labelScreenshot.AllowParentOverrides = false;
            this.labelScreenshot.AutoEllipsis = false;
            this.labelScreenshot.AutoSize = false;
            this.labelScreenshot.Cursor = System.Windows.Forms.Cursors.Default;
            this.labelScreenshot.CursorType = System.Windows.Forms.Cursors.Default;
            this.labelScreenshot.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Italic);
            this.labelScreenshot.ForeColor = System.Drawing.Color.White;
            this.labelScreenshot.Location = new System.Drawing.Point(62, 89);
            this.labelScreenshot.Name = "labelScreenshot";
            this.labelScreenshot.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.labelScreenshot.Size = new System.Drawing.Size(89, 21);
            this.labelScreenshot.TabIndex = 10;
            this.labelScreenshot.Text = "Screenshot";
            this.labelScreenshot.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.labelScreenshot.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // chklSystemInfo
            // 
            this.chklSystemInfo.AccessibleRole = System.Windows.Forms.AccessibleRole.CheckButton;
            this.chklSystemInfo.AllowParentOverrides = false;
            this.chklSystemInfo.AutoEllipsis = false;
            this.chklSystemInfo.AutoSize = false;
            this.chklSystemInfo.Cursor = System.Windows.Forms.Cursors.Default;
            this.chklSystemInfo.CursorType = System.Windows.Forms.Cursors.Default;
            this.chklSystemInfo.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Italic);
            this.chklSystemInfo.ForeColor = System.Drawing.Color.White;
            this.chklSystemInfo.Location = new System.Drawing.Point(62, 145);
            this.chklSystemInfo.Name = "chklSystemInfo";
            this.chklSystemInfo.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.chklSystemInfo.Size = new System.Drawing.Size(102, 21);
            this.chklSystemInfo.TabIndex = 10;
            this.chklSystemInfo.Text = "System Info";
            this.chklSystemInfo.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.chklSystemInfo.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // chkScreenshot
            // 
            this.chkScreenshot.AllowBindingControlAnimation = true;
            this.chkScreenshot.AllowBindingControlColorChanges = false;
            this.chkScreenshot.AllowBindingControlLocation = true;
            this.chkScreenshot.AllowCheckBoxAnimation = false;
            this.chkScreenshot.AllowCheckmarkAnimation = true;
            this.chkScreenshot.AllowOnHoverStates = true;
            this.chkScreenshot.AutoCheck = true;
            this.chkScreenshot.BackColor = System.Drawing.Color.Transparent;
            this.chkScreenshot.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chkScreenshot.BackgroundImage")));
            this.chkScreenshot.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.chkScreenshot.BindingControl = this.labelScreenshot;
            this.chkScreenshot.BindingControlPosition = Bunifu.UI.WinForms.BunifuCheckBox.BindingControlPositions.Right;
            this.chkScreenshot.BorderRadius = 5;
            this.chkScreenshot.Checked = true;
            this.chkScreenshot.CheckState = Bunifu.UI.WinForms.BunifuCheckBox.CheckStates.Checked;
            this.chkScreenshot.Cursor = System.Windows.Forms.Cursors.Default;
            this.chkScreenshot.CustomCheckmarkImage = null;
            this.chkScreenshot.Location = new System.Drawing.Point(38, 85);
            this.chkScreenshot.MinimumSize = new System.Drawing.Size(17, 17);
            this.chkScreenshot.Name = "chkScreenshot";
            this.chkScreenshot.OnCheck.BorderColor = System.Drawing.Color.White;
            this.chkScreenshot.OnCheck.BorderRadius = 5;
            this.chkScreenshot.OnCheck.BorderThickness = 2;
            this.chkScreenshot.OnCheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkScreenshot.OnCheck.CheckmarkColor = System.Drawing.Color.White;
            this.chkScreenshot.OnCheck.CheckmarkThickness = 2;
            this.chkScreenshot.OnDisable.BorderColor = System.Drawing.Color.LightGray;
            this.chkScreenshot.OnDisable.BorderRadius = 5;
            this.chkScreenshot.OnDisable.BorderThickness = 2;
            this.chkScreenshot.OnDisable.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkScreenshot.OnDisable.CheckmarkColor = System.Drawing.Color.LightGray;
            this.chkScreenshot.OnDisable.CheckmarkThickness = 2;
            this.chkScreenshot.OnHoverChecked.BorderColor = System.Drawing.Color.White;
            this.chkScreenshot.OnHoverChecked.BorderRadius = 5;
            this.chkScreenshot.OnHoverChecked.BorderThickness = 2;
            this.chkScreenshot.OnHoverChecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkScreenshot.OnHoverChecked.CheckmarkColor = System.Drawing.Color.White;
            this.chkScreenshot.OnHoverChecked.CheckmarkThickness = 2;
            this.chkScreenshot.OnHoverUnchecked.BorderColor = System.Drawing.Color.White;
            this.chkScreenshot.OnHoverUnchecked.BorderRadius = 5;
            this.chkScreenshot.OnHoverUnchecked.BorderThickness = 1;
            this.chkScreenshot.OnHoverUnchecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkScreenshot.OnUncheck.BorderColor = System.Drawing.Color.DarkGray;
            this.chkScreenshot.OnUncheck.BorderRadius = 5;
            this.chkScreenshot.OnUncheck.BorderThickness = 1;
            this.chkScreenshot.OnUncheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkScreenshot.Size = new System.Drawing.Size(21, 21);
            this.chkScreenshot.Style = Bunifu.UI.WinForms.BunifuCheckBox.CheckBoxStyles.Bunifu;
            this.chkScreenshot.TabIndex = 9;
            this.chkScreenshot.ThreeState = false;
            this.chkScreenshot.ToolTipText = null;
            this.chkScreenshot.CheckedChanged += new System.EventHandler<Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs>(this.CheckedChanged);
            // 
            // chkSystemInfo
            // 
            this.chkSystemInfo.AllowBindingControlAnimation = true;
            this.chkSystemInfo.AllowBindingControlColorChanges = false;
            this.chkSystemInfo.AllowBindingControlLocation = true;
            this.chkSystemInfo.AllowCheckBoxAnimation = false;
            this.chkSystemInfo.AllowCheckmarkAnimation = true;
            this.chkSystemInfo.AllowOnHoverStates = true;
            this.chkSystemInfo.AutoCheck = true;
            this.chkSystemInfo.BackColor = System.Drawing.Color.Transparent;
            this.chkSystemInfo.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chkSystemInfo.BackgroundImage")));
            this.chkSystemInfo.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.chkSystemInfo.BindingControl = this.chklSystemInfo;
            this.chkSystemInfo.BindingControlPosition = Bunifu.UI.WinForms.BunifuCheckBox.BindingControlPositions.Right;
            this.chkSystemInfo.BorderRadius = 5;
            this.chkSystemInfo.Checked = true;
            this.chkSystemInfo.CheckState = Bunifu.UI.WinForms.BunifuCheckBox.CheckStates.Checked;
            this.chkSystemInfo.Cursor = System.Windows.Forms.Cursors.Default;
            this.chkSystemInfo.CustomCheckmarkImage = null;
            this.chkSystemInfo.Location = new System.Drawing.Point(38, 141);
            this.chkSystemInfo.MinimumSize = new System.Drawing.Size(17, 17);
            this.chkSystemInfo.Name = "chkSystemInfo";
            this.chkSystemInfo.OnCheck.BorderColor = System.Drawing.Color.White;
            this.chkSystemInfo.OnCheck.BorderRadius = 5;
            this.chkSystemInfo.OnCheck.BorderThickness = 2;
            this.chkSystemInfo.OnCheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkSystemInfo.OnCheck.CheckmarkColor = System.Drawing.Color.White;
            this.chkSystemInfo.OnCheck.CheckmarkThickness = 2;
            this.chkSystemInfo.OnDisable.BorderColor = System.Drawing.Color.LightGray;
            this.chkSystemInfo.OnDisable.BorderRadius = 5;
            this.chkSystemInfo.OnDisable.BorderThickness = 2;
            this.chkSystemInfo.OnDisable.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkSystemInfo.OnDisable.CheckmarkColor = System.Drawing.Color.LightGray;
            this.chkSystemInfo.OnDisable.CheckmarkThickness = 2;
            this.chkSystemInfo.OnHoverChecked.BorderColor = System.Drawing.Color.White;
            this.chkSystemInfo.OnHoverChecked.BorderRadius = 5;
            this.chkSystemInfo.OnHoverChecked.BorderThickness = 2;
            this.chkSystemInfo.OnHoverChecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkSystemInfo.OnHoverChecked.CheckmarkColor = System.Drawing.Color.White;
            this.chkSystemInfo.OnHoverChecked.CheckmarkThickness = 2;
            this.chkSystemInfo.OnHoverUnchecked.BorderColor = System.Drawing.Color.White;
            this.chkSystemInfo.OnHoverUnchecked.BorderRadius = 5;
            this.chkSystemInfo.OnHoverUnchecked.BorderThickness = 1;
            this.chkSystemInfo.OnHoverUnchecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkSystemInfo.OnUncheck.BorderColor = System.Drawing.Color.DarkGray;
            this.chkSystemInfo.OnUncheck.BorderRadius = 5;
            this.chkSystemInfo.OnUncheck.BorderThickness = 1;
            this.chkSystemInfo.OnUncheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkSystemInfo.Size = new System.Drawing.Size(21, 21);
            this.chkSystemInfo.Style = Bunifu.UI.WinForms.BunifuCheckBox.CheckBoxStyles.Bunifu;
            this.chkSystemInfo.TabIndex = 9;
            this.chkSystemInfo.ThreeState = false;
            this.chkSystemInfo.ToolTipText = null;
            this.chkSystemInfo.CheckedChanged += new System.EventHandler<Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs>(this.CheckedChanged);
            // 
            // labelBrowserCookies
            // 
            this.labelBrowserCookies.AccessibleRole = System.Windows.Forms.AccessibleRole.CheckButton;
            this.labelBrowserCookies.AllowParentOverrides = false;
            this.labelBrowserCookies.AutoEllipsis = false;
            this.labelBrowserCookies.Cursor = System.Windows.Forms.Cursors.Default;
            this.labelBrowserCookies.CursorType = System.Windows.Forms.Cursors.Default;
            this.labelBrowserCookies.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Italic);
            this.labelBrowserCookies.ForeColor = System.Drawing.Color.White;
            this.labelBrowserCookies.Location = new System.Drawing.Point(205, 89);
            this.labelBrowserCookies.Name = "labelBrowserCookies";
            this.labelBrowserCookies.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.labelBrowserCookies.Size = new System.Drawing.Size(116, 21);
            this.labelBrowserCookies.TabIndex = 4;
            this.labelBrowserCookies.Text = "Browser Cookies";
            this.labelBrowserCookies.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.labelBrowserCookies.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // chkCookies
            // 
            this.chkCookies.AllowBindingControlAnimation = true;
            this.chkCookies.AllowBindingControlColorChanges = false;
            this.chkCookies.AllowBindingControlLocation = true;
            this.chkCookies.AllowCheckBoxAnimation = false;
            this.chkCookies.AllowCheckmarkAnimation = true;
            this.chkCookies.AllowOnHoverStates = true;
            this.chkCookies.AutoCheck = true;
            this.chkCookies.BackColor = System.Drawing.Color.Transparent;
            this.chkCookies.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chkCookies.BackgroundImage")));
            this.chkCookies.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.chkCookies.BindingControl = this.labelBrowserCookies;
            this.chkCookies.BindingControlPosition = Bunifu.UI.WinForms.BunifuCheckBox.BindingControlPositions.Right;
            this.chkCookies.BorderRadius = 5;
            this.chkCookies.Checked = true;
            this.chkCookies.CheckState = Bunifu.UI.WinForms.BunifuCheckBox.CheckStates.Checked;
            this.chkCookies.Cursor = System.Windows.Forms.Cursors.Default;
            this.chkCookies.CustomCheckmarkImage = null;
            this.chkCookies.Location = new System.Drawing.Point(181, 85);
            this.chkCookies.MinimumSize = new System.Drawing.Size(17, 17);
            this.chkCookies.Name = "chkCookies";
            this.chkCookies.OnCheck.BorderColor = System.Drawing.Color.White;
            this.chkCookies.OnCheck.BorderRadius = 5;
            this.chkCookies.OnCheck.BorderThickness = 2;
            this.chkCookies.OnCheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkCookies.OnCheck.CheckmarkColor = System.Drawing.Color.White;
            this.chkCookies.OnCheck.CheckmarkThickness = 2;
            this.chkCookies.OnDisable.BorderColor = System.Drawing.Color.LightGray;
            this.chkCookies.OnDisable.BorderRadius = 5;
            this.chkCookies.OnDisable.BorderThickness = 2;
            this.chkCookies.OnDisable.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkCookies.OnDisable.CheckmarkColor = System.Drawing.Color.LightGray;
            this.chkCookies.OnDisable.CheckmarkThickness = 2;
            this.chkCookies.OnHoverChecked.BorderColor = System.Drawing.Color.White;
            this.chkCookies.OnHoverChecked.BorderRadius = 5;
            this.chkCookies.OnHoverChecked.BorderThickness = 2;
            this.chkCookies.OnHoverChecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkCookies.OnHoverChecked.CheckmarkColor = System.Drawing.Color.White;
            this.chkCookies.OnHoverChecked.CheckmarkThickness = 2;
            this.chkCookies.OnHoverUnchecked.BorderColor = System.Drawing.Color.White;
            this.chkCookies.OnHoverUnchecked.BorderRadius = 5;
            this.chkCookies.OnHoverUnchecked.BorderThickness = 1;
            this.chkCookies.OnHoverUnchecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkCookies.OnUncheck.BorderColor = System.Drawing.Color.DarkGray;
            this.chkCookies.OnUncheck.BorderRadius = 5;
            this.chkCookies.OnUncheck.BorderThickness = 1;
            this.chkCookies.OnUncheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkCookies.Size = new System.Drawing.Size(21, 21);
            this.chkCookies.Style = Bunifu.UI.WinForms.BunifuCheckBox.CheckBoxStyles.Bunifu;
            this.chkCookies.TabIndex = 3;
            this.chkCookies.ThreeState = false;
            this.chkCookies.ToolTipText = null;
            this.chkCookies.CheckedChanged += new System.EventHandler<Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs>(this.CheckedChanged);
            // 
            // labelBrowserPasswords
            // 
            this.labelBrowserPasswords.AccessibleRole = System.Windows.Forms.AccessibleRole.CheckButton;
            this.labelBrowserPasswords.AllowParentOverrides = false;
            this.labelBrowserPasswords.AutoEllipsis = false;
            this.labelBrowserPasswords.Cursor = System.Windows.Forms.Cursors.Default;
            this.labelBrowserPasswords.CursorType = System.Windows.Forms.Cursors.Default;
            this.labelBrowserPasswords.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelBrowserPasswords.ForeColor = System.Drawing.Color.White;
            this.labelBrowserPasswords.Location = new System.Drawing.Point(205, 35);
            this.labelBrowserPasswords.Name = "labelBrowserPasswords";
            this.labelBrowserPasswords.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.labelBrowserPasswords.Size = new System.Drawing.Size(135, 21);
            this.labelBrowserPasswords.TabIndex = 4;
            this.labelBrowserPasswords.Text = "Browser Passwords";
            this.labelBrowserPasswords.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.labelBrowserPasswords.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // chkPasswords
            // 
            this.chkPasswords.AllowBindingControlAnimation = true;
            this.chkPasswords.AllowBindingControlColorChanges = false;
            this.chkPasswords.AllowBindingControlLocation = true;
            this.chkPasswords.AllowCheckBoxAnimation = false;
            this.chkPasswords.AllowCheckmarkAnimation = true;
            this.chkPasswords.AllowOnHoverStates = true;
            this.chkPasswords.AutoCheck = true;
            this.chkPasswords.BackColor = System.Drawing.Color.Transparent;
            this.chkPasswords.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chkPasswords.BackgroundImage")));
            this.chkPasswords.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.chkPasswords.BindingControl = this.labelBrowserPasswords;
            this.chkPasswords.BindingControlPosition = Bunifu.UI.WinForms.BunifuCheckBox.BindingControlPositions.Right;
            this.chkPasswords.BorderRadius = 5;
            this.chkPasswords.Checked = true;
            this.chkPasswords.CheckState = Bunifu.UI.WinForms.BunifuCheckBox.CheckStates.Checked;
            this.chkPasswords.Cursor = System.Windows.Forms.Cursors.Default;
            this.chkPasswords.CustomCheckmarkImage = null;
            this.chkPasswords.Location = new System.Drawing.Point(181, 31);
            this.chkPasswords.MinimumSize = new System.Drawing.Size(17, 17);
            this.chkPasswords.Name = "chkPasswords";
            this.chkPasswords.OnCheck.BorderColor = System.Drawing.Color.White;
            this.chkPasswords.OnCheck.BorderRadius = 5;
            this.chkPasswords.OnCheck.BorderThickness = 2;
            this.chkPasswords.OnCheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkPasswords.OnCheck.CheckmarkColor = System.Drawing.Color.White;
            this.chkPasswords.OnCheck.CheckmarkThickness = 2;
            this.chkPasswords.OnDisable.BorderColor = System.Drawing.Color.LightGray;
            this.chkPasswords.OnDisable.BorderRadius = 5;
            this.chkPasswords.OnDisable.BorderThickness = 2;
            this.chkPasswords.OnDisable.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkPasswords.OnDisable.CheckmarkColor = System.Drawing.Color.LightGray;
            this.chkPasswords.OnDisable.CheckmarkThickness = 2;
            this.chkPasswords.OnHoverChecked.BorderColor = System.Drawing.Color.White;
            this.chkPasswords.OnHoverChecked.BorderRadius = 5;
            this.chkPasswords.OnHoverChecked.BorderThickness = 2;
            this.chkPasswords.OnHoverChecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkPasswords.OnHoverChecked.CheckmarkColor = System.Drawing.Color.White;
            this.chkPasswords.OnHoverChecked.CheckmarkThickness = 2;
            this.chkPasswords.OnHoverUnchecked.BorderColor = System.Drawing.Color.White;
            this.chkPasswords.OnHoverUnchecked.BorderRadius = 5;
            this.chkPasswords.OnHoverUnchecked.BorderThickness = 1;
            this.chkPasswords.OnHoverUnchecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkPasswords.OnUncheck.BorderColor = System.Drawing.Color.DarkGray;
            this.chkPasswords.OnUncheck.BorderRadius = 5;
            this.chkPasswords.OnUncheck.BorderThickness = 1;
            this.chkPasswords.OnUncheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkPasswords.Size = new System.Drawing.Size(21, 21);
            this.chkPasswords.Style = Bunifu.UI.WinForms.BunifuCheckBox.CheckBoxStyles.Bunifu;
            this.chkPasswords.TabIndex = 3;
            this.chkPasswords.ThreeState = false;
            this.chkPasswords.ToolTipText = null;
            this.chkPasswords.CheckedChanged += new System.EventHandler<Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs>(this.CheckedChanged);
            // 
            // labelDiscordTokens
            // 
            this.labelDiscordTokens.AccessibleRole = System.Windows.Forms.AccessibleRole.CheckButton;
            this.labelDiscordTokens.AllowParentOverrides = false;
            this.labelDiscordTokens.AutoEllipsis = false;
            this.labelDiscordTokens.Cursor = System.Windows.Forms.Cursors.Default;
            this.labelDiscordTokens.CursorType = System.Windows.Forms.Cursors.Default;
            this.labelDiscordTokens.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Italic);
            this.labelDiscordTokens.ForeColor = System.Drawing.Color.White;
            this.labelDiscordTokens.Location = new System.Drawing.Point(205, 149);
            this.labelDiscordTokens.Name = "labelDiscordTokens";
            this.labelDiscordTokens.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.labelDiscordTokens.Size = new System.Drawing.Size(106, 21);
            this.labelDiscordTokens.TabIndex = 2;
            this.labelDiscordTokens.Text = "Discord Tokens";
            this.labelDiscordTokens.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.labelDiscordTokens.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // chkDiscord
            // 
            this.chkDiscord.AllowBindingControlAnimation = true;
            this.chkDiscord.AllowBindingControlColorChanges = false;
            this.chkDiscord.AllowBindingControlLocation = true;
            this.chkDiscord.AllowCheckBoxAnimation = false;
            this.chkDiscord.AllowCheckmarkAnimation = true;
            this.chkDiscord.AllowOnHoverStates = true;
            this.chkDiscord.AutoCheck = true;
            this.chkDiscord.BackColor = System.Drawing.Color.Transparent;
            this.chkDiscord.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chkDiscord.BackgroundImage")));
            this.chkDiscord.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.chkDiscord.BindingControl = this.labelDiscordTokens;
            this.chkDiscord.BindingControlPosition = Bunifu.UI.WinForms.BunifuCheckBox.BindingControlPositions.Right;
            this.chkDiscord.BorderRadius = 5;
            this.chkDiscord.Checked = true;
            this.chkDiscord.CheckState = Bunifu.UI.WinForms.BunifuCheckBox.CheckStates.Checked;
            this.chkDiscord.Cursor = System.Windows.Forms.Cursors.Default;
            this.chkDiscord.CustomCheckmarkImage = null;
            this.chkDiscord.Location = new System.Drawing.Point(181, 145);
            this.chkDiscord.MinimumSize = new System.Drawing.Size(17, 17);
            this.chkDiscord.Name = "chkDiscord";
            this.chkDiscord.OnCheck.BorderColor = System.Drawing.Color.White;
            this.chkDiscord.OnCheck.BorderRadius = 5;
            this.chkDiscord.OnCheck.BorderThickness = 2;
            this.chkDiscord.OnCheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkDiscord.OnCheck.CheckmarkColor = System.Drawing.Color.White;
            this.chkDiscord.OnCheck.CheckmarkThickness = 2;
            this.chkDiscord.OnDisable.BorderColor = System.Drawing.Color.LightGray;
            this.chkDiscord.OnDisable.BorderRadius = 5;
            this.chkDiscord.OnDisable.BorderThickness = 2;
            this.chkDiscord.OnDisable.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkDiscord.OnDisable.CheckmarkColor = System.Drawing.Color.LightGray;
            this.chkDiscord.OnDisable.CheckmarkThickness = 2;
            this.chkDiscord.OnHoverChecked.BorderColor = System.Drawing.Color.White;
            this.chkDiscord.OnHoverChecked.BorderRadius = 5;
            this.chkDiscord.OnHoverChecked.BorderThickness = 2;
            this.chkDiscord.OnHoverChecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkDiscord.OnHoverChecked.CheckmarkColor = System.Drawing.Color.White;
            this.chkDiscord.OnHoverChecked.CheckmarkThickness = 2;
            this.chkDiscord.OnHoverUnchecked.BorderColor = System.Drawing.Color.White;
            this.chkDiscord.OnHoverUnchecked.BorderRadius = 5;
            this.chkDiscord.OnHoverUnchecked.BorderThickness = 1;
            this.chkDiscord.OnHoverUnchecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkDiscord.OnUncheck.BorderColor = System.Drawing.Color.DarkGray;
            this.chkDiscord.OnUncheck.BorderRadius = 5;
            this.chkDiscord.OnUncheck.BorderThickness = 1;
            this.chkDiscord.OnUncheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkDiscord.Size = new System.Drawing.Size(21, 21);
            this.chkDiscord.Style = Bunifu.UI.WinForms.BunifuCheckBox.CheckBoxStyles.Bunifu;
            this.chkDiscord.TabIndex = 1;
            this.chkDiscord.ThreeState = false;
            this.chkDiscord.ToolTipText = null;
            this.chkDiscord.CheckedChanged += new System.EventHandler<Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs>(this.CheckedChanged);
            // 
            // btnModifyAssembly
            // 
            this.btnModifyAssembly.AllowAnimations = true;
            this.btnModifyAssembly.AllowMouseEffects = true;
            this.btnModifyAssembly.AllowToggling = false;
            this.btnModifyAssembly.AnimationSpeed = 200;
            this.btnModifyAssembly.AutoGenerateColors = false;
            this.btnModifyAssembly.AutoRoundBorders = false;
            this.btnModifyAssembly.AutoSizeLeftIcon = true;
            this.btnModifyAssembly.AutoSizeRightIcon = true;
            this.btnModifyAssembly.BackColor = System.Drawing.Color.Transparent;
            this.btnModifyAssembly.BackColor1 = System.Drawing.Color.Transparent;
            this.btnModifyAssembly.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnModifyAssembly.BackgroundImage")));
            this.btnModifyAssembly.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnModifyAssembly.ButtonText = "Assembly";
            this.btnModifyAssembly.ButtonTextMarginLeft = 0;
            this.btnModifyAssembly.ColorContrastOnClick = 45;
            this.btnModifyAssembly.ColorContrastOnHover = 45;
            this.btnModifyAssembly.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges9.BottomLeft = true;
            borderEdges9.BottomRight = true;
            borderEdges9.TopLeft = true;
            borderEdges9.TopRight = true;
            this.btnModifyAssembly.CustomizableEdges = borderEdges9;
            this.btnModifyAssembly.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnModifyAssembly.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnModifyAssembly.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnModifyAssembly.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnModifyAssembly.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Idle;
            this.btnModifyAssembly.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnModifyAssembly.ForeColor = System.Drawing.Color.White;
            this.btnModifyAssembly.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnModifyAssembly.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnModifyAssembly.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnModifyAssembly.IconMarginLeft = 11;
            this.btnModifyAssembly.IconPadding = 10;
            this.btnModifyAssembly.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnModifyAssembly.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnModifyAssembly.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnModifyAssembly.IconSize = 25;
            this.btnModifyAssembly.IdleBorderColor = System.Drawing.Color.Silver;
            this.btnModifyAssembly.IdleBorderRadius = 1;
            this.btnModifyAssembly.IdleBorderThickness = 1;
            this.btnModifyAssembly.IdleFillColor = System.Drawing.Color.Transparent;
            this.btnModifyAssembly.IdleIconLeftImage = null;
            this.btnModifyAssembly.IdleIconRightImage = null;
            this.btnModifyAssembly.IndicateFocus = false;
            this.btnModifyAssembly.Location = new System.Drawing.Point(42, 296);
            this.btnModifyAssembly.Margin = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.btnModifyAssembly.Name = "btnModifyAssembly";
            this.btnModifyAssembly.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnModifyAssembly.OnDisabledState.BorderRadius = 1;
            this.btnModifyAssembly.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnModifyAssembly.OnDisabledState.BorderThickness = 1;
            this.btnModifyAssembly.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnModifyAssembly.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnModifyAssembly.OnDisabledState.IconLeftImage = null;
            this.btnModifyAssembly.OnDisabledState.IconRightImage = null;
            this.btnModifyAssembly.onHoverState.BorderColor = System.Drawing.Color.White;
            this.btnModifyAssembly.onHoverState.BorderRadius = 1;
            this.btnModifyAssembly.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnModifyAssembly.onHoverState.BorderThickness = 1;
            this.btnModifyAssembly.onHoverState.FillColor = System.Drawing.Color.Gray;
            this.btnModifyAssembly.onHoverState.ForeColor = System.Drawing.Color.Transparent;
            this.btnModifyAssembly.onHoverState.IconLeftImage = null;
            this.btnModifyAssembly.onHoverState.IconRightImage = null;
            this.btnModifyAssembly.OnIdleState.BorderColor = System.Drawing.Color.Silver;
            this.btnModifyAssembly.OnIdleState.BorderRadius = 1;
            this.btnModifyAssembly.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnModifyAssembly.OnIdleState.BorderThickness = 1;
            this.btnModifyAssembly.OnIdleState.FillColor = System.Drawing.Color.Transparent;
            this.btnModifyAssembly.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnModifyAssembly.OnIdleState.IconLeftImage = null;
            this.btnModifyAssembly.OnIdleState.IconRightImage = null;
            this.btnModifyAssembly.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.btnModifyAssembly.OnPressedState.BorderRadius = 1;
            this.btnModifyAssembly.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnModifyAssembly.OnPressedState.BorderThickness = 1;
            this.btnModifyAssembly.OnPressedState.FillColor = System.Drawing.Color.Gray;
            this.btnModifyAssembly.OnPressedState.ForeColor = System.Drawing.Color.Transparent;
            this.btnModifyAssembly.OnPressedState.IconLeftImage = null;
            this.btnModifyAssembly.OnPressedState.IconRightImage = null;
            this.btnModifyAssembly.Size = new System.Drawing.Size(138, 60);
            this.btnModifyAssembly.TabIndex = 2;
            this.btnModifyAssembly.TabStop = false;
            this.btnModifyAssembly.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnModifyAssembly.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnModifyAssembly.TextMarginLeft = 0;
            this.btnModifyAssembly.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnModifyAssembly.UseDefaultRadiusAndThickness = true;
            this.btnModifyAssembly.Click += new System.EventHandler(this.btnModifyAssembly_Click);
            // 
            // txtVersion
            // 
            this.txtVersion.AllowParentOverrides = false;
            this.txtVersion.AutoEllipsis = false;
            this.txtVersion.Cursor = System.Windows.Forms.Cursors.Default;
            this.txtVersion.CursorType = System.Windows.Forms.Cursors.Default;
            this.txtVersion.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.txtVersion.ForeColor = System.Drawing.Color.White;
            this.txtVersion.Location = new System.Drawing.Point(120, 399);
            this.txtVersion.Name = "txtVersion";
            this.txtVersion.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.txtVersion.Size = new System.Drawing.Size(394, 15);
            this.txtVersion.TabIndex = 3;
            this.txtVersion.Text = "Attention: This tool is for educational purposes only! Developed by: Py_Dev";
            this.txtVersion.TextAlignment = System.Drawing.ContentAlignment.MiddleCenter;
            this.txtVersion.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // btnIconSelect
            // 
            this.btnIconSelect.AllowAnimations = true;
            this.btnIconSelect.AllowMouseEffects = true;
            this.btnIconSelect.AllowToggling = false;
            this.btnIconSelect.AnimationSpeed = 200;
            this.btnIconSelect.AutoGenerateColors = false;
            this.btnIconSelect.AutoRoundBorders = false;
            this.btnIconSelect.AutoSizeLeftIcon = true;
            this.btnIconSelect.AutoSizeRightIcon = true;
            this.btnIconSelect.BackColor = System.Drawing.Color.Transparent;
            this.btnIconSelect.BackColor1 = System.Drawing.Color.Transparent;
            this.btnIconSelect.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnIconSelect.BackgroundImage")));
            this.btnIconSelect.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnIconSelect.ButtonText = "Icon";
            this.btnIconSelect.ButtonTextMarginLeft = 0;
            this.btnIconSelect.ColorContrastOnClick = 45;
            this.btnIconSelect.ColorContrastOnHover = 45;
            this.btnIconSelect.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges10.BottomLeft = true;
            borderEdges10.BottomRight = true;
            borderEdges10.TopLeft = true;
            borderEdges10.TopRight = true;
            this.btnIconSelect.CustomizableEdges = borderEdges10;
            this.btnIconSelect.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnIconSelect.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnIconSelect.DisabledFillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnIconSelect.DisabledForecolor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnIconSelect.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Idle;
            this.btnIconSelect.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnIconSelect.ForeColor = System.Drawing.Color.White;
            this.btnIconSelect.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnIconSelect.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnIconSelect.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnIconSelect.IconMarginLeft = 11;
            this.btnIconSelect.IconPadding = 10;
            this.btnIconSelect.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnIconSelect.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnIconSelect.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnIconSelect.IconSize = 25;
            this.btnIconSelect.IdleBorderColor = System.Drawing.Color.Silver;
            this.btnIconSelect.IdleBorderRadius = 1;
            this.btnIconSelect.IdleBorderThickness = 1;
            this.btnIconSelect.IdleFillColor = System.Drawing.Color.Transparent;
            this.btnIconSelect.IdleIconLeftImage = null;
            this.btnIconSelect.IdleIconRightImage = null;
            this.btnIconSelect.IndicateFocus = false;
            this.btnIconSelect.Location = new System.Drawing.Point(231, 296);
            this.btnIconSelect.Margin = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.btnIconSelect.Name = "btnIconSelect";
            this.btnIconSelect.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(191)))), ((int)(((byte)(191)))), ((int)(((byte)(191)))));
            this.btnIconSelect.OnDisabledState.BorderRadius = 1;
            this.btnIconSelect.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnIconSelect.OnDisabledState.BorderThickness = 1;
            this.btnIconSelect.OnDisabledState.FillColor = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.btnIconSelect.OnDisabledState.ForeColor = System.Drawing.Color.FromArgb(((int)(((byte)(168)))), ((int)(((byte)(160)))), ((int)(((byte)(168)))));
            this.btnIconSelect.OnDisabledState.IconLeftImage = null;
            this.btnIconSelect.OnDisabledState.IconRightImage = null;
            this.btnIconSelect.onHoverState.BorderColor = System.Drawing.Color.White;
            this.btnIconSelect.onHoverState.BorderRadius = 1;
            this.btnIconSelect.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnIconSelect.onHoverState.BorderThickness = 1;
            this.btnIconSelect.onHoverState.FillColor = System.Drawing.Color.Gray;
            this.btnIconSelect.onHoverState.ForeColor = System.Drawing.Color.Transparent;
            this.btnIconSelect.onHoverState.IconLeftImage = null;
            this.btnIconSelect.onHoverState.IconRightImage = null;
            this.btnIconSelect.OnIdleState.BorderColor = System.Drawing.Color.Silver;
            this.btnIconSelect.OnIdleState.BorderRadius = 1;
            this.btnIconSelect.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnIconSelect.OnIdleState.BorderThickness = 1;
            this.btnIconSelect.OnIdleState.FillColor = System.Drawing.Color.Transparent;
            this.btnIconSelect.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnIconSelect.OnIdleState.IconLeftImage = null;
            this.btnIconSelect.OnIdleState.IconRightImage = null;
            this.btnIconSelect.OnPressedState.BorderColor = System.Drawing.Color.White;
            this.btnIconSelect.OnPressedState.BorderRadius = 1;
            this.btnIconSelect.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnIconSelect.OnPressedState.BorderThickness = 1;
            this.btnIconSelect.OnPressedState.FillColor = System.Drawing.Color.Gray;
            this.btnIconSelect.OnPressedState.ForeColor = System.Drawing.Color.Transparent;
            this.btnIconSelect.OnPressedState.IconLeftImage = null;
            this.btnIconSelect.OnPressedState.IconRightImage = null;
            this.btnIconSelect.Size = new System.Drawing.Size(138, 60);
            this.btnIconSelect.TabIndex = 2;
            this.btnIconSelect.TabStop = false;
            this.btnIconSelect.Tag = "NoIcon";
            this.btnIconSelect.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnIconSelect.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnIconSelect.TextMarginLeft = 0;
            this.btnIconSelect.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnIconSelect.UseDefaultRadiusAndThickness = true;
            this.btnIconSelect.Click += new System.EventHandler(this.btnIconSelect_Click);
            // 
            // btnBuild
            // 
            this.btnBuild.AllowAnimations = true;
            this.btnBuild.AllowMouseEffects = true;
            this.btnBuild.AllowToggling = false;
            this.btnBuild.AnimationSpeed = 200;
            this.btnBuild.AutoGenerateColors = false;
            this.btnBuild.AutoRoundBorders = false;
            this.btnBuild.AutoSizeLeftIcon = true;
            this.btnBuild.AutoSizeRightIcon = true;
            this.btnBuild.BackColor = System.Drawing.Color.Transparent;
            this.btnBuild.BackColor1 = System.Drawing.Color.Transparent;
            this.btnBuild.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnBuild.BackgroundImage")));
            this.btnBuild.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnBuild.ButtonText = "Build";
            this.btnBuild.ButtonTextMarginLeft = 0;
            this.btnBuild.ColorContrastOnClick = 45;
            this.btnBuild.ColorContrastOnHover = 45;
            this.btnBuild.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges11.BottomLeft = true;
            borderEdges11.BottomRight = true;
            borderEdges11.TopLeft = true;
            borderEdges11.TopRight = true;
            this.btnBuild.CustomizableEdges = borderEdges11;
            this.btnBuild.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnBuild.DisabledBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBuild.DisabledFillColor = System.Drawing.Color.Transparent;
            this.btnBuild.DisabledForecolor = System.Drawing.Color.White;
            this.btnBuild.Enabled = false;
            this.btnBuild.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnBuild.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnBuild.ForeColor = System.Drawing.Color.White;
            this.btnBuild.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnBuild.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnBuild.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnBuild.IconMarginLeft = 11;
            this.btnBuild.IconPadding = 10;
            this.btnBuild.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnBuild.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnBuild.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnBuild.IconSize = 25;
            this.btnBuild.IdleBorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBuild.IdleBorderRadius = 1;
            this.btnBuild.IdleBorderThickness = 1;
            this.btnBuild.IdleFillColor = System.Drawing.Color.Transparent;
            this.btnBuild.IdleIconLeftImage = null;
            this.btnBuild.IdleIconRightImage = null;
            this.btnBuild.IndicateFocus = false;
            this.btnBuild.Location = new System.Drawing.Point(406, 296);
            this.btnBuild.Name = "btnBuild";
            this.btnBuild.OnDisabledState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBuild.OnDisabledState.BorderRadius = 1;
            this.btnBuild.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnBuild.OnDisabledState.BorderThickness = 1;
            this.btnBuild.OnDisabledState.FillColor = System.Drawing.Color.Transparent;
            this.btnBuild.OnDisabledState.ForeColor = System.Drawing.Color.White;
            this.btnBuild.OnDisabledState.IconLeftImage = null;
            this.btnBuild.OnDisabledState.IconRightImage = null;
            this.btnBuild.onHoverState.BorderColor = System.Drawing.Color.Lime;
            this.btnBuild.onHoverState.BorderRadius = 1;
            this.btnBuild.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnBuild.onHoverState.BorderThickness = 1;
            this.btnBuild.onHoverState.FillColor = System.Drawing.Color.Gray;
            this.btnBuild.onHoverState.ForeColor = System.Drawing.Color.Transparent;
            this.btnBuild.onHoverState.IconLeftImage = null;
            this.btnBuild.onHoverState.IconRightImage = null;
            this.btnBuild.OnIdleState.BorderColor = System.Drawing.Color.FromArgb(((int)(((byte)(128)))), ((int)(((byte)(255)))), ((int)(((byte)(128)))));
            this.btnBuild.OnIdleState.BorderRadius = 1;
            this.btnBuild.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnBuild.OnIdleState.BorderThickness = 1;
            this.btnBuild.OnIdleState.FillColor = System.Drawing.Color.Transparent;
            this.btnBuild.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnBuild.OnIdleState.IconLeftImage = null;
            this.btnBuild.OnIdleState.IconRightImage = null;
            this.btnBuild.OnPressedState.BorderColor = System.Drawing.Color.Lime;
            this.btnBuild.OnPressedState.BorderRadius = 1;
            this.btnBuild.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnBuild.OnPressedState.BorderThickness = 1;
            this.btnBuild.OnPressedState.FillColor = System.Drawing.Color.Transparent;
            this.btnBuild.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnBuild.OnPressedState.IconLeftImage = null;
            this.btnBuild.OnPressedState.IconRightImage = null;
            this.btnBuild.Size = new System.Drawing.Size(201, 60);
            this.btnBuild.TabIndex = 2;
            this.btnBuild.TabStop = false;
            this.btnBuild.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnBuild.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnBuild.TextMarginLeft = 0;
            this.btnBuild.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnBuild.UseDefaultRadiusAndThickness = true;
            this.btnBuild.Click += new System.EventHandler(this.btnBuild_Click);
            // 
            // btnCheckWebhook
            // 
            this.btnCheckWebhook.AllowAnimations = true;
            this.btnCheckWebhook.AllowMouseEffects = true;
            this.btnCheckWebhook.AllowToggling = false;
            this.btnCheckWebhook.AnimationSpeed = 200;
            this.btnCheckWebhook.AutoGenerateColors = false;
            this.btnCheckWebhook.AutoRoundBorders = false;
            this.btnCheckWebhook.AutoSizeLeftIcon = true;
            this.btnCheckWebhook.AutoSizeRightIcon = true;
            this.btnCheckWebhook.BackColor = System.Drawing.Color.Transparent;
            this.btnCheckWebhook.BackColor1 = System.Drawing.Color.Transparent;
            this.btnCheckWebhook.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("btnCheckWebhook.BackgroundImage")));
            this.btnCheckWebhook.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnCheckWebhook.ButtonText = "Verify";
            this.btnCheckWebhook.ButtonTextMarginLeft = 0;
            this.btnCheckWebhook.ColorContrastOnClick = 45;
            this.btnCheckWebhook.ColorContrastOnHover = 45;
            this.btnCheckWebhook.Cursor = System.Windows.Forms.Cursors.Default;
            borderEdges12.BottomLeft = true;
            borderEdges12.BottomRight = true;
            borderEdges12.TopLeft = true;
            borderEdges12.TopRight = true;
            this.btnCheckWebhook.CustomizableEdges = borderEdges12;
            this.btnCheckWebhook.DialogResult = System.Windows.Forms.DialogResult.None;
            this.btnCheckWebhook.DisabledBorderColor = System.Drawing.Color.Silver;
            this.btnCheckWebhook.DisabledFillColor = System.Drawing.Color.Transparent;
            this.btnCheckWebhook.DisabledForecolor = System.Drawing.Color.White;
            this.btnCheckWebhook.FocusState = Bunifu.UI.WinForms.BunifuButton.BunifuButton.ButtonStates.Pressed;
            this.btnCheckWebhook.Font = new System.Drawing.Font("Segoe UI", 9F);
            this.btnCheckWebhook.ForeColor = System.Drawing.Color.White;
            this.btnCheckWebhook.IconLeftAlign = System.Drawing.ContentAlignment.MiddleLeft;
            this.btnCheckWebhook.IconLeftCursor = System.Windows.Forms.Cursors.Default;
            this.btnCheckWebhook.IconLeftPadding = new System.Windows.Forms.Padding(11, 3, 3, 3);
            this.btnCheckWebhook.IconMarginLeft = 11;
            this.btnCheckWebhook.IconPadding = 10;
            this.btnCheckWebhook.IconRightAlign = System.Drawing.ContentAlignment.MiddleRight;
            this.btnCheckWebhook.IconRightCursor = System.Windows.Forms.Cursors.Default;
            this.btnCheckWebhook.IconRightPadding = new System.Windows.Forms.Padding(3, 3, 7, 3);
            this.btnCheckWebhook.IconSize = 25;
            this.btnCheckWebhook.IdleBorderColor = System.Drawing.Color.Gray;
            this.btnCheckWebhook.IdleBorderRadius = 1;
            this.btnCheckWebhook.IdleBorderThickness = 1;
            this.btnCheckWebhook.IdleFillColor = System.Drawing.Color.Transparent;
            this.btnCheckWebhook.IdleIconLeftImage = null;
            this.btnCheckWebhook.IdleIconRightImage = null;
            this.btnCheckWebhook.IndicateFocus = false;
            this.btnCheckWebhook.Location = new System.Drawing.Point(520, 28);
            this.btnCheckWebhook.Name = "btnCheckWebhook";
            this.btnCheckWebhook.OnDisabledState.BorderColor = System.Drawing.Color.Silver;
            this.btnCheckWebhook.OnDisabledState.BorderRadius = 1;
            this.btnCheckWebhook.OnDisabledState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnCheckWebhook.OnDisabledState.BorderThickness = 1;
            this.btnCheckWebhook.OnDisabledState.FillColor = System.Drawing.Color.Transparent;
            this.btnCheckWebhook.OnDisabledState.ForeColor = System.Drawing.Color.White;
            this.btnCheckWebhook.OnDisabledState.IconLeftImage = null;
            this.btnCheckWebhook.OnDisabledState.IconRightImage = null;
            this.btnCheckWebhook.onHoverState.BorderColor = System.Drawing.Color.Silver;
            this.btnCheckWebhook.onHoverState.BorderRadius = 1;
            this.btnCheckWebhook.onHoverState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnCheckWebhook.onHoverState.BorderThickness = 1;
            this.btnCheckWebhook.onHoverState.FillColor = System.Drawing.Color.Gray;
            this.btnCheckWebhook.onHoverState.ForeColor = System.Drawing.Color.Transparent;
            this.btnCheckWebhook.onHoverState.IconLeftImage = null;
            this.btnCheckWebhook.onHoverState.IconRightImage = null;
            this.btnCheckWebhook.OnIdleState.BorderColor = System.Drawing.Color.Gray;
            this.btnCheckWebhook.OnIdleState.BorderRadius = 1;
            this.btnCheckWebhook.OnIdleState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnCheckWebhook.OnIdleState.BorderThickness = 1;
            this.btnCheckWebhook.OnIdleState.FillColor = System.Drawing.Color.Transparent;
            this.btnCheckWebhook.OnIdleState.ForeColor = System.Drawing.Color.White;
            this.btnCheckWebhook.OnIdleState.IconLeftImage = null;
            this.btnCheckWebhook.OnIdleState.IconRightImage = null;
            this.btnCheckWebhook.OnPressedState.BorderColor = System.Drawing.Color.Silver;
            this.btnCheckWebhook.OnPressedState.BorderRadius = 1;
            this.btnCheckWebhook.OnPressedState.BorderStyle = Bunifu.UI.WinForms.BunifuButton.BunifuButton.BorderStyles.Solid;
            this.btnCheckWebhook.OnPressedState.BorderThickness = 1;
            this.btnCheckWebhook.OnPressedState.FillColor = System.Drawing.Color.Transparent;
            this.btnCheckWebhook.OnPressedState.ForeColor = System.Drawing.Color.White;
            this.btnCheckWebhook.OnPressedState.IconLeftImage = null;
            this.btnCheckWebhook.OnPressedState.IconRightImage = null;
            this.btnCheckWebhook.Size = new System.Drawing.Size(87, 32);
            this.btnCheckWebhook.TabIndex = 2;
            this.btnCheckWebhook.TabStop = false;
            this.btnCheckWebhook.TextAlign = System.Drawing.ContentAlignment.MiddleCenter;
            this.btnCheckWebhook.TextAlignment = System.Windows.Forms.HorizontalAlignment.Center;
            this.btnCheckWebhook.TextMarginLeft = 0;
            this.btnCheckWebhook.TextPadding = new System.Windows.Forms.Padding(0);
            this.btnCheckWebhook.UseDefaultRadiusAndThickness = true;
            this.btnCheckWebhook.Click += new System.EventHandler(this.btnCheckWebhook_Click);
            // 
            // grpBasic
            // 
            this.grpBasic.BackColor = System.Drawing.Color.Black;
            this.grpBasic.Controls.Add(this.labelBlockAvSites);
            this.grpBasic.Controls.Add(this.chkBlockAvSites);
            this.grpBasic.Controls.Add(this.labelMelt);
            this.grpBasic.Controls.Add(this.chkMelt);
            this.grpBasic.Controls.Add(this.labelAntiVm);
            this.grpBasic.Controls.Add(this.chkAntiVm);
            this.grpBasic.Controls.Add(this.labelAddToStartup);
            this.grpBasic.Controls.Add(this.chkStartup);
            this.grpBasic.ForeColor = System.Drawing.Color.Silver;
            this.grpBasic.Location = new System.Drawing.Point(406, 70);
            this.grpBasic.Margin = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.grpBasic.Name = "grpBasic";
            this.grpBasic.Padding = new System.Windows.Forms.Padding(6, 3, 6, 3);
            this.grpBasic.Size = new System.Drawing.Size(201, 206);
            this.grpBasic.TabIndex = 1;
            this.grpBasic.TabStop = false;
            this.grpBasic.Text = "Install";
            // 
            // labelBlockAvSites
            // 
            this.labelBlockAvSites.AccessibleRole = System.Windows.Forms.AccessibleRole.CheckButton;
            this.labelBlockAvSites.AllowParentOverrides = false;
            this.labelBlockAvSites.AutoEllipsis = false;
            this.labelBlockAvSites.Cursor = System.Windows.Forms.Cursors.Default;
            this.labelBlockAvSites.CursorType = System.Windows.Forms.Cursors.Default;
            this.labelBlockAvSites.Font = new System.Drawing.Font("Yu Gothic UI", 12F);
            this.labelBlockAvSites.ForeColor = System.Drawing.Color.White;
            this.labelBlockAvSites.Location = new System.Drawing.Point(52, 123);
            this.labelBlockAvSites.Name = "labelBlockAvSites";
            this.labelBlockAvSites.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.labelBlockAvSites.Size = new System.Drawing.Size(98, 21);
            this.labelBlockAvSites.TabIndex = 12;
            this.labelBlockAvSites.Text = "Block AV Sites";
            this.labelBlockAvSites.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.labelBlockAvSites.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // chkBlockAvSites
            // 
            this.chkBlockAvSites.AllowBindingControlAnimation = true;
            this.chkBlockAvSites.AllowBindingControlColorChanges = false;
            this.chkBlockAvSites.AllowBindingControlLocation = true;
            this.chkBlockAvSites.AllowCheckBoxAnimation = false;
            this.chkBlockAvSites.AllowCheckmarkAnimation = true;
            this.chkBlockAvSites.AllowOnHoverStates = true;
            this.chkBlockAvSites.AutoCheck = true;
            this.chkBlockAvSites.BackColor = System.Drawing.Color.Transparent;
            this.chkBlockAvSites.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chkBlockAvSites.BackgroundImage")));
            this.chkBlockAvSites.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.chkBlockAvSites.BindingControl = this.labelBlockAvSites;
            this.chkBlockAvSites.BindingControlPosition = Bunifu.UI.WinForms.BunifuCheckBox.BindingControlPositions.Right;
            this.chkBlockAvSites.BorderRadius = 5;
            this.chkBlockAvSites.Checked = true;
            this.chkBlockAvSites.CheckState = Bunifu.UI.WinForms.BunifuCheckBox.CheckStates.Checked;
            this.chkBlockAvSites.Cursor = System.Windows.Forms.Cursors.Default;
            this.chkBlockAvSites.CustomCheckmarkImage = null;
            this.chkBlockAvSites.Location = new System.Drawing.Point(28, 119);
            this.chkBlockAvSites.MinimumSize = new System.Drawing.Size(17, 17);
            this.chkBlockAvSites.Name = "chkBlockAvSites";
            this.chkBlockAvSites.OnCheck.BorderColor = System.Drawing.Color.White;
            this.chkBlockAvSites.OnCheck.BorderRadius = 5;
            this.chkBlockAvSites.OnCheck.BorderThickness = 2;
            this.chkBlockAvSites.OnCheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkBlockAvSites.OnCheck.CheckmarkColor = System.Drawing.Color.White;
            this.chkBlockAvSites.OnCheck.CheckmarkThickness = 2;
            this.chkBlockAvSites.OnDisable.BorderColor = System.Drawing.Color.LightGray;
            this.chkBlockAvSites.OnDisable.BorderRadius = 5;
            this.chkBlockAvSites.OnDisable.BorderThickness = 2;
            this.chkBlockAvSites.OnDisable.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkBlockAvSites.OnDisable.CheckmarkColor = System.Drawing.Color.LightGray;
            this.chkBlockAvSites.OnDisable.CheckmarkThickness = 2;
            this.chkBlockAvSites.OnHoverChecked.BorderColor = System.Drawing.Color.White;
            this.chkBlockAvSites.OnHoverChecked.BorderRadius = 5;
            this.chkBlockAvSites.OnHoverChecked.BorderThickness = 2;
            this.chkBlockAvSites.OnHoverChecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkBlockAvSites.OnHoverChecked.CheckmarkColor = System.Drawing.Color.White;
            this.chkBlockAvSites.OnHoverChecked.CheckmarkThickness = 2;
            this.chkBlockAvSites.OnHoverUnchecked.BorderColor = System.Drawing.Color.White;
            this.chkBlockAvSites.OnHoverUnchecked.BorderRadius = 5;
            this.chkBlockAvSites.OnHoverUnchecked.BorderThickness = 1;
            this.chkBlockAvSites.OnHoverUnchecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkBlockAvSites.OnUncheck.BorderColor = System.Drawing.Color.DarkGray;
            this.chkBlockAvSites.OnUncheck.BorderRadius = 5;
            this.chkBlockAvSites.OnUncheck.BorderThickness = 1;
            this.chkBlockAvSites.OnUncheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkBlockAvSites.Size = new System.Drawing.Size(21, 21);
            this.chkBlockAvSites.Style = Bunifu.UI.WinForms.BunifuCheckBox.CheckBoxStyles.Bunifu;
            this.chkBlockAvSites.TabIndex = 11;
            this.chkBlockAvSites.ThreeState = false;
            this.chkBlockAvSites.ToolTipText = null;
            this.chkBlockAvSites.CheckedChanged += new System.EventHandler<Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs>(this.CheckedChanged);
            // 
            // labelMelt
            // 
            this.labelMelt.AccessibleRole = System.Windows.Forms.AccessibleRole.CheckButton;
            this.labelMelt.AllowParentOverrides = false;
            this.labelMelt.AutoEllipsis = false;
            this.labelMelt.Cursor = System.Windows.Forms.Cursors.Default;
            this.labelMelt.CursorType = System.Windows.Forms.Cursors.Default;
            this.labelMelt.Font = new System.Drawing.Font("Yu Gothic UI", 12F);
            this.labelMelt.ForeColor = System.Drawing.Color.White;
            this.labelMelt.Location = new System.Drawing.Point(52, 78);
            this.labelMelt.Name = "labelMelt";
            this.labelMelt.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.labelMelt.Size = new System.Drawing.Size(31, 21);
            this.labelMelt.TabIndex = 10;
            this.labelMelt.Text = "Melt";
            this.labelMelt.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.labelMelt.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // chkMelt
            // 
            this.chkMelt.AllowBindingControlAnimation = true;
            this.chkMelt.AllowBindingControlColorChanges = false;
            this.chkMelt.AllowBindingControlLocation = true;
            this.chkMelt.AllowCheckBoxAnimation = false;
            this.chkMelt.AllowCheckmarkAnimation = true;
            this.chkMelt.AllowOnHoverStates = true;
            this.chkMelt.AutoCheck = true;
            this.chkMelt.BackColor = System.Drawing.Color.Transparent;
            this.chkMelt.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chkMelt.BackgroundImage")));
            this.chkMelt.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.chkMelt.BindingControl = this.labelMelt;
            this.chkMelt.BindingControlPosition = Bunifu.UI.WinForms.BunifuCheckBox.BindingControlPositions.Right;
            this.chkMelt.BorderRadius = 5;
            this.chkMelt.Checked = true;
            this.chkMelt.CheckState = Bunifu.UI.WinForms.BunifuCheckBox.CheckStates.Checked;
            this.chkMelt.Cursor = System.Windows.Forms.Cursors.Default;
            this.chkMelt.CustomCheckmarkImage = null;
            this.chkMelt.Location = new System.Drawing.Point(28, 74);
            this.chkMelt.MinimumSize = new System.Drawing.Size(17, 17);
            this.chkMelt.Name = "chkMelt";
            this.chkMelt.OnCheck.BorderColor = System.Drawing.Color.White;
            this.chkMelt.OnCheck.BorderRadius = 5;
            this.chkMelt.OnCheck.BorderThickness = 2;
            this.chkMelt.OnCheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkMelt.OnCheck.CheckmarkColor = System.Drawing.Color.White;
            this.chkMelt.OnCheck.CheckmarkThickness = 2;
            this.chkMelt.OnDisable.BorderColor = System.Drawing.Color.LightGray;
            this.chkMelt.OnDisable.BorderRadius = 5;
            this.chkMelt.OnDisable.BorderThickness = 2;
            this.chkMelt.OnDisable.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkMelt.OnDisable.CheckmarkColor = System.Drawing.Color.LightGray;
            this.chkMelt.OnDisable.CheckmarkThickness = 2;
            this.chkMelt.OnHoverChecked.BorderColor = System.Drawing.Color.White;
            this.chkMelt.OnHoverChecked.BorderRadius = 5;
            this.chkMelt.OnHoverChecked.BorderThickness = 2;
            this.chkMelt.OnHoverChecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkMelt.OnHoverChecked.CheckmarkColor = System.Drawing.Color.White;
            this.chkMelt.OnHoverChecked.CheckmarkThickness = 2;
            this.chkMelt.OnHoverUnchecked.BorderColor = System.Drawing.Color.White;
            this.chkMelt.OnHoverUnchecked.BorderRadius = 5;
            this.chkMelt.OnHoverUnchecked.BorderThickness = 1;
            this.chkMelt.OnHoverUnchecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkMelt.OnUncheck.BorderColor = System.Drawing.Color.DarkGray;
            this.chkMelt.OnUncheck.BorderRadius = 5;
            this.chkMelt.OnUncheck.BorderThickness = 1;
            this.chkMelt.OnUncheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkMelt.Size = new System.Drawing.Size(21, 21);
            this.chkMelt.Style = Bunifu.UI.WinForms.BunifuCheckBox.CheckBoxStyles.Bunifu;
            this.chkMelt.TabIndex = 9;
            this.chkMelt.ThreeState = false;
            this.chkMelt.ToolTipText = null;
            this.chkMelt.CheckedChanged += new System.EventHandler<Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs>(this.CheckedChanged);
            // 
            // labelAntiVm
            // 
            this.labelAntiVm.AccessibleRole = System.Windows.Forms.AccessibleRole.CheckButton;
            this.labelAntiVm.AllowParentOverrides = false;
            this.labelAntiVm.AutoEllipsis = false;
            this.labelAntiVm.Cursor = System.Windows.Forms.Cursors.Default;
            this.labelAntiVm.CursorType = System.Windows.Forms.Cursors.Default;
            this.labelAntiVm.Font = new System.Drawing.Font("Yu Gothic UI", 12F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.labelAntiVm.ForeColor = System.Drawing.Color.White;
            this.labelAntiVm.Location = new System.Drawing.Point(52, 35);
            this.labelAntiVm.Name = "labelAntiVm";
            this.labelAntiVm.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.labelAntiVm.Size = new System.Drawing.Size(56, 21);
            this.labelAntiVm.TabIndex = 8;
            this.labelAntiVm.Text = "Anti VM";
            this.labelAntiVm.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.labelAntiVm.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // chkAntiVm
            // 
            this.chkAntiVm.AllowBindingControlAnimation = true;
            this.chkAntiVm.AllowBindingControlColorChanges = false;
            this.chkAntiVm.AllowBindingControlLocation = true;
            this.chkAntiVm.AllowCheckBoxAnimation = false;
            this.chkAntiVm.AllowCheckmarkAnimation = true;
            this.chkAntiVm.AllowOnHoverStates = true;
            this.chkAntiVm.AutoCheck = true;
            this.chkAntiVm.BackColor = System.Drawing.Color.Transparent;
            this.chkAntiVm.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chkAntiVm.BackgroundImage")));
            this.chkAntiVm.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.chkAntiVm.BindingControl = this.labelAntiVm;
            this.chkAntiVm.BindingControlPosition = Bunifu.UI.WinForms.BunifuCheckBox.BindingControlPositions.Right;
            this.chkAntiVm.BorderRadius = 5;
            this.chkAntiVm.Checked = true;
            this.chkAntiVm.CheckState = Bunifu.UI.WinForms.BunifuCheckBox.CheckStates.Checked;
            this.chkAntiVm.Cursor = System.Windows.Forms.Cursors.Default;
            this.chkAntiVm.CustomCheckmarkImage = null;
            this.chkAntiVm.Location = new System.Drawing.Point(28, 31);
            this.chkAntiVm.MinimumSize = new System.Drawing.Size(17, 17);
            this.chkAntiVm.Name = "chkAntiVm";
            this.chkAntiVm.OnCheck.BorderColor = System.Drawing.Color.White;
            this.chkAntiVm.OnCheck.BorderRadius = 5;
            this.chkAntiVm.OnCheck.BorderThickness = 2;
            this.chkAntiVm.OnCheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkAntiVm.OnCheck.CheckmarkColor = System.Drawing.Color.White;
            this.chkAntiVm.OnCheck.CheckmarkThickness = 2;
            this.chkAntiVm.OnDisable.BorderColor = System.Drawing.Color.LightGray;
            this.chkAntiVm.OnDisable.BorderRadius = 5;
            this.chkAntiVm.OnDisable.BorderThickness = 2;
            this.chkAntiVm.OnDisable.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkAntiVm.OnDisable.CheckmarkColor = System.Drawing.Color.LightGray;
            this.chkAntiVm.OnDisable.CheckmarkThickness = 2;
            this.chkAntiVm.OnHoverChecked.BorderColor = System.Drawing.Color.White;
            this.chkAntiVm.OnHoverChecked.BorderRadius = 5;
            this.chkAntiVm.OnHoverChecked.BorderThickness = 2;
            this.chkAntiVm.OnHoverChecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkAntiVm.OnHoverChecked.CheckmarkColor = System.Drawing.Color.White;
            this.chkAntiVm.OnHoverChecked.CheckmarkThickness = 2;
            this.chkAntiVm.OnHoverUnchecked.BorderColor = System.Drawing.Color.White;
            this.chkAntiVm.OnHoverUnchecked.BorderRadius = 5;
            this.chkAntiVm.OnHoverUnchecked.BorderThickness = 1;
            this.chkAntiVm.OnHoverUnchecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkAntiVm.OnUncheck.BorderColor = System.Drawing.Color.DarkGray;
            this.chkAntiVm.OnUncheck.BorderRadius = 5;
            this.chkAntiVm.OnUncheck.BorderThickness = 1;
            this.chkAntiVm.OnUncheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkAntiVm.Size = new System.Drawing.Size(21, 21);
            this.chkAntiVm.Style = Bunifu.UI.WinForms.BunifuCheckBox.CheckBoxStyles.Bunifu;
            this.chkAntiVm.TabIndex = 7;
            this.chkAntiVm.ThreeState = false;
            this.chkAntiVm.ToolTipText = null;
            this.chkAntiVm.CheckedChanged += new System.EventHandler<Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs>(this.CheckedChanged);
            // 
            // labelAddToStartup
            // 
            this.labelAddToStartup.AccessibleRole = System.Windows.Forms.AccessibleRole.CheckButton;
            this.labelAddToStartup.AllowParentOverrides = false;
            this.labelAddToStartup.AutoEllipsis = false;
            this.labelAddToStartup.Cursor = System.Windows.Forms.Cursors.Default;
            this.labelAddToStartup.CursorType = System.Windows.Forms.Cursors.Default;
            this.labelAddToStartup.Font = new System.Drawing.Font("Yu Gothic UI", 12F);
            this.labelAddToStartup.ForeColor = System.Drawing.Color.White;
            this.labelAddToStartup.Location = new System.Drawing.Point(52, 170);
            this.labelAddToStartup.Name = "labelAddToStartup";
            this.labelAddToStartup.RightToLeft = System.Windows.Forms.RightToLeft.No;
            this.labelAddToStartup.Size = new System.Drawing.Size(104, 21);
            this.labelAddToStartup.TabIndex = 6;
            this.labelAddToStartup.Text = "Add To Startup";
            this.labelAddToStartup.TextAlignment = System.Drawing.ContentAlignment.TopLeft;
            this.labelAddToStartup.TextFormat = Bunifu.UI.WinForms.BunifuLabel.TextFormattingOptions.Default;
            // 
            // chkStartup
            // 
            this.chkStartup.AllowBindingControlAnimation = true;
            this.chkStartup.AllowBindingControlColorChanges = false;
            this.chkStartup.AllowBindingControlLocation = true;
            this.chkStartup.AllowCheckBoxAnimation = false;
            this.chkStartup.AllowCheckmarkAnimation = true;
            this.chkStartup.AllowOnHoverStates = true;
            this.chkStartup.AutoCheck = true;
            this.chkStartup.BackColor = System.Drawing.Color.Transparent;
            this.chkStartup.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("chkStartup.BackgroundImage")));
            this.chkStartup.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Zoom;
            this.chkStartup.BindingControl = this.labelAddToStartup;
            this.chkStartup.BindingControlPosition = Bunifu.UI.WinForms.BunifuCheckBox.BindingControlPositions.Right;
            this.chkStartup.BorderRadius = 5;
            this.chkStartup.Checked = true;
            this.chkStartup.CheckState = Bunifu.UI.WinForms.BunifuCheckBox.CheckStates.Checked;
            this.chkStartup.Cursor = System.Windows.Forms.Cursors.Default;
            this.chkStartup.CustomCheckmarkImage = null;
            this.chkStartup.Location = new System.Drawing.Point(28, 166);
            this.chkStartup.MinimumSize = new System.Drawing.Size(17, 17);
            this.chkStartup.Name = "chkStartup";
            this.chkStartup.OnCheck.BorderColor = System.Drawing.Color.White;
            this.chkStartup.OnCheck.BorderRadius = 5;
            this.chkStartup.OnCheck.BorderThickness = 2;
            this.chkStartup.OnCheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkStartup.OnCheck.CheckmarkColor = System.Drawing.Color.White;
            this.chkStartup.OnCheck.CheckmarkThickness = 2;
            this.chkStartup.OnDisable.BorderColor = System.Drawing.Color.LightGray;
            this.chkStartup.OnDisable.BorderRadius = 5;
            this.chkStartup.OnDisable.BorderThickness = 2;
            this.chkStartup.OnDisable.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkStartup.OnDisable.CheckmarkColor = System.Drawing.Color.LightGray;
            this.chkStartup.OnDisable.CheckmarkThickness = 2;
            this.chkStartup.OnHoverChecked.BorderColor = System.Drawing.Color.White;
            this.chkStartup.OnHoverChecked.BorderRadius = 5;
            this.chkStartup.OnHoverChecked.BorderThickness = 2;
            this.chkStartup.OnHoverChecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkStartup.OnHoverChecked.CheckmarkColor = System.Drawing.Color.White;
            this.chkStartup.OnHoverChecked.CheckmarkThickness = 2;
            this.chkStartup.OnHoverUnchecked.BorderColor = System.Drawing.Color.White;
            this.chkStartup.OnHoverUnchecked.BorderRadius = 5;
            this.chkStartup.OnHoverUnchecked.BorderThickness = 1;
            this.chkStartup.OnHoverUnchecked.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkStartup.OnUncheck.BorderColor = System.Drawing.Color.DarkGray;
            this.chkStartup.OnUncheck.BorderRadius = 5;
            this.chkStartup.OnUncheck.BorderThickness = 1;
            this.chkStartup.OnUncheck.CheckBoxColor = System.Drawing.Color.Transparent;
            this.chkStartup.Size = new System.Drawing.Size(21, 21);
            this.chkStartup.Style = Bunifu.UI.WinForms.BunifuCheckBox.CheckBoxStyles.Bunifu;
            this.chkStartup.TabIndex = 5;
            this.chkStartup.ThreeState = false;
            this.chkStartup.ToolTipText = null;
            this.chkStartup.CheckedChanged += new System.EventHandler<Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs>(this.CheckedChanged);
            // 
            // txtWebhook
            // 
            this.txtWebhook.AcceptsReturn = false;
            this.txtWebhook.AcceptsTab = false;
            this.txtWebhook.AnimationSpeed = 200;
            this.txtWebhook.AutoCompleteMode = System.Windows.Forms.AutoCompleteMode.None;
            this.txtWebhook.AutoCompleteSource = System.Windows.Forms.AutoCompleteSource.None;
            this.txtWebhook.BackColor = System.Drawing.Color.White;
            this.txtWebhook.BackgroundImage = ((System.Drawing.Image)(resources.GetObject("txtWebhook.BackgroundImage")));
            this.txtWebhook.BorderColorActive = System.Drawing.Color.Transparent;
            this.txtWebhook.BorderColorDisabled = System.Drawing.Color.FromArgb(((int)(((byte)(204)))), ((int)(((byte)(204)))), ((int)(((byte)(204)))));
            this.txtWebhook.BorderColorHover = System.Drawing.Color.Transparent;
            this.txtWebhook.BorderColorIdle = System.Drawing.Color.Silver;
            this.txtWebhook.BorderRadius = 1;
            this.txtWebhook.BorderThickness = 1;
            this.txtWebhook.CharacterCasing = System.Windows.Forms.CharacterCasing.Normal;
            this.txtWebhook.Cursor = System.Windows.Forms.Cursors.IBeam;
            this.txtWebhook.DefaultFont = new System.Drawing.Font("Segoe UI", 9.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.txtWebhook.DefaultText = "";
            this.txtWebhook.FillColor = System.Drawing.Color.Black;
            this.txtWebhook.HideSelection = true;
            this.txtWebhook.IconLeft = null;
            this.txtWebhook.IconLeftCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtWebhook.IconPadding = 10;
            this.txtWebhook.IconRight = null;
            this.txtWebhook.IconRightCursor = System.Windows.Forms.Cursors.IBeam;
            this.txtWebhook.Lines = new string[0];
            this.txtWebhook.Location = new System.Drawing.Point(16, 28);
            this.txtWebhook.MaxLength = 32767;
            this.txtWebhook.MinimumSize = new System.Drawing.Size(1, 1);
            this.txtWebhook.Modified = false;
            this.txtWebhook.Multiline = false;
            this.txtWebhook.Name = "txtWebhook";
            stateProperties9.BorderColor = System.Drawing.Color.Transparent;
            stateProperties9.FillColor = System.Drawing.Color.Empty;
            stateProperties9.ForeColor = System.Drawing.Color.Empty;
            stateProperties9.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtWebhook.OnActiveState = stateProperties9;
            stateProperties10.BorderColor = System.Drawing.Color.Silver;
            stateProperties10.FillColor = System.Drawing.Color.Black;
            stateProperties10.ForeColor = System.Drawing.Color.Transparent;
            stateProperties10.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.txtWebhook.OnDisabledState = stateProperties10;
            stateProperties11.BorderColor = System.Drawing.Color.Transparent;
            stateProperties11.FillColor = System.Drawing.Color.Empty;
            stateProperties11.ForeColor = System.Drawing.Color.Empty;
            stateProperties11.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtWebhook.OnHoverState = stateProperties11;
            stateProperties12.BorderColor = System.Drawing.Color.Silver;
            stateProperties12.FillColor = System.Drawing.Color.Black;
            stateProperties12.ForeColor = System.Drawing.Color.Empty;
            stateProperties12.PlaceholderForeColor = System.Drawing.Color.Empty;
            this.txtWebhook.OnIdleState = stateProperties12;
            this.txtWebhook.Padding = new System.Windows.Forms.Padding(3);
            this.txtWebhook.PasswordChar = '\0';
            this.txtWebhook.PlaceholderForeColor = System.Drawing.Color.Gray;
            this.txtWebhook.PlaceholderText = "https://discord.com/api/webhooks/";
            this.txtWebhook.ReadOnly = false;
            this.txtWebhook.ScrollBars = System.Windows.Forms.ScrollBars.None;
            this.txtWebhook.SelectedText = "";
            this.txtWebhook.SelectionLength = 0;
            this.txtWebhook.SelectionStart = 0;
            this.txtWebhook.ShortcutsEnabled = true;
            this.txtWebhook.Size = new System.Drawing.Size(498, 32);
            this.txtWebhook.Style = Bunifu.UI.WinForms.BunifuTextBox._Style.Bunifu;
            this.txtWebhook.TabIndex = 0;
            this.txtWebhook.TextAlign = System.Windows.Forms.HorizontalAlignment.Left;
            this.txtWebhook.TextMarginBottom = 0;
            this.txtWebhook.TextMarginLeft = 3;
            this.txtWebhook.TextMarginTop = 0;
            this.txtWebhook.TextPlaceholder = "https://discord.com/api/webhooks/";
            this.txtWebhook.UseSystemPasswordChar = false;
            this.txtWebhook.WordWrap = true;
            this.txtWebhook.TextChanged += new System.EventHandler(this.txtWebhook_TextChanged);
            // 
            // MainForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.Gray;
            this.ClientSize = new System.Drawing.Size(633, 464);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Name = "MainForm";
            this.Padding = new System.Windows.Forms.Padding(2);
            this.ShowIcon = false;
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Divulge Stealer [Builder]";
            this.panel1.ResumeLayout(false);
            this.panel2.ResumeLayout(false);
            this.bunifuShadowPanel2.ResumeLayout(false);
            this.bunifuShadowPanel2.PerformLayout();
            this.grpOptions.ResumeLayout(false);
            this.grpOptions.PerformLayout();
            this.grpBasic.ResumeLayout(false);
            this.grpBasic.PerformLayout();
            this.ResumeLayout(false);

        }

        #endregion
        private Bunifu.UI.WinForms.BunifuColorTransition bunifuColorTransition1;
        private Bunifu.Framework.UI.BunifuElipse bunifuElipse2;
        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button buttonClose;
        private System.Windows.Forms.Button buttonMinimize;
        private System.Windows.Forms.Panel panel2;
        private Bunifu.UI.WinForms.BunifuShadowPanel bunifuShadowPanel2;
        private Bunifu.UI.WinForms.BunifuLabel bunifuLabel1;
        private Bunifu.UI.WinForms.BunifuTextBox txtWebhook;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnCheckWebhook;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnBuild;
        private System.Windows.Forms.GroupBox grpBasic;
        private System.Windows.Forms.GroupBox grpOptions;
        private Bunifu.UI.WinForms.BunifuLabel txtVersion;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnModifyAssembly;
        private Bunifu.UI.WinForms.BunifuButton.BunifuButton btnIconSelect;
        private Bunifu.UI.WinForms.BunifuCheckBox chkDiscord;
        private Bunifu.UI.WinForms.BunifuLabel labelDiscordTokens;
        private Bunifu.UI.WinForms.BunifuLabel labelWallets;
        private Bunifu.UI.WinForms.BunifuCheckBox chkWallets;
        private Bunifu.UI.WinForms.BunifuLabel chklSystemInfo;
        private Bunifu.UI.WinForms.BunifuCheckBox chkSystemInfo;
        private Bunifu.UI.WinForms.BunifuLabel labelBrowserCookies;
        private Bunifu.UI.WinForms.BunifuCheckBox chkCookies;
        private Bunifu.UI.WinForms.BunifuLabel labelBrowserPasswords;
        private Bunifu.UI.WinForms.BunifuCheckBox chkPasswords;
        private Bunifu.UI.WinForms.BunifuLabel labelScreenshot;
        private Bunifu.UI.WinForms.BunifuCheckBox chkScreenshot;
        private Bunifu.UI.WinForms.BunifuLabel labelMelt;
        private Bunifu.UI.WinForms.BunifuCheckBox chkMelt;
        private Bunifu.UI.WinForms.BunifuLabel labelAntiVm;
        private Bunifu.UI.WinForms.BunifuCheckBox chkAntiVm;
        private Bunifu.UI.WinForms.BunifuLabel labelAddToStartup;
        private Bunifu.UI.WinForms.BunifuCheckBox chkStartup;
        private Bunifu.UI.WinForms.BunifuLabel labelBlockAvSites;
        private Bunifu.UI.WinForms.BunifuCheckBox chkBlockAvSites;
        private System.Windows.Forms.Label label1;
    }
}